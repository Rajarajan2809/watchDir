package folder_watcher;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLDecoder;

import org.apache.commons.io.FilenameUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class httpClient
{
	private String url, jsonData, fileName, type;
	private String serverIp = "172.16.1.55";
	//private String serverIp = "172.16.9.151:8087";
	private utilities U1 = new utilities();

	httpClient(String url, String type, String jsonData, String fileName, boolean destStat)
	{
		if(destStat)//server ip
			this.url = "http://" + serverIp + url;
		else
			this.url = "http://localhost:8888"+ url;
		this.jsonData = jsonData;															
		this.type = type;
		this.fileName = fileName;
	}

	private String json_pretty_print(String json)
	{
		if(!json.isEmpty())
		{
			json = json.replace("{","{\n    ");
			json = json.replace(",",",\n    ");
			json = json.replace("}","\n}");
			//System.out.println("JSON:"+json);
			return json;
		}
		else
			return "";
	}
	
	public String httpRequest() throws ClientProtocolException, IOException
	{
		String httpResp = "";
		
		CloseableHttpClient client = HttpClients.createDefault();
		
		switch(type)
		{
			case "GET":
			default:
			{
				HttpGet request = new HttpGet(url);
				
				CloseableHttpResponse response = client.execute(request);
				if(response.getStatusLine().getStatusCode() == 200)
				{
					// Get the response
					BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			
					StringBuffer curlResp = new StringBuffer();
					
					String line = "";
					while ((line = rd.readLine()) != null)
					{
						curlResp.append(line);
						//status = true;
					}
					httpResp = curlResp.toString();
				}
				client.close();
			}
			break;
			
			case "POST":
			{
				HttpPost httpPost = new HttpPost(url);
			 
			    StringEntity entity = new StringEntity(jsonData);
			    httpPost.setEntity(entity);
			    httpPost.setHeader("Accept", "application/json");
			    httpPost.setHeader("Content-type", "application/json");
			 
			    CloseableHttpResponse response = client.execute(httpPost);
			    if(response.getStatusLine().getStatusCode() == 200)
				{
					// Get the response
					BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			
					StringBuffer curlResp = new StringBuffer();
					
					String line = "";
					while ((line = rd.readLine()) != null)
					{
						curlResp.append(line);
						//status = true;
					}
					httpResp = curlResp.toString();
				}
			    //assertThat(response.getStatusLine().getStatusCode(), equalTo(200));
			    client.close();
			}
			break;
			
			case "PUT":
			{
				HttpPut httpPut = new HttpPut(url);
				StringEntity entity = new StringEntity(jsonData);
				httpPut.setEntity(entity);
				httpPut.setHeader("Accept", "application/json");
				httpPut.setHeader("Content-type", "application/json");

				CloseableHttpResponse response = client.execute(httpPut);
				if (response.getStatusLine().getStatusCode() == 200)
				{
					BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
					StringBuffer curlResp = new StringBuffer();
					String line = "";
					while ((line = rd.readLine()) != null)
					{
						curlResp.append(line);
						// status = true;
					}
					httpResp = curlResp.toString();
				}
			}
			break;
		}
		return httpResp;
	}

	@SuppressWarnings("unchecked")
	public boolean mailConstruct(String group,String status, String subject, String attachment, String errParam) throws IOException, ParseException
	{
		boolean mailStatus = false;
		
		System.out.println("(Thread Process) group:"+group);
		//System.out.println("(Thread Process) mail_id:"+mail_id);
		System.out.println("(Thread Process) subject:"+subject);
		System.out.println("(Thread Process) status:"+status);
		System.out.println("(Thread Process) attachment:"+attachment+"\n");
		System.out.println("(Thread Process) errParam:"+errParam+"\n");
		
		consoleLog.log("(Thread Process) group:"+group);
		//System.out.println("(Thread Process) mail_id:"+mail_id);
		consoleLog.log("(Thread Process) subject:"+subject);
		consoleLog.log("(Thread Process) status:"+status);
		consoleLog.log("(Thread Process) attachment:"+attachment+"\n");
		consoleLog.log("(Thread Process) errParam:"+errParam+"\n");
		
		String mailGrpResponse="";
		if(!subject.equals("DB"))
		{
			consoleLog.log("(Thread Process) URL:/maestro/getMailConfig?groupName="+group+"\",type:\"GET\"\n");
			System.out.println("(Thread Process) URL:/maestro/getMailConfig?groupName="+group+"\",type:\"GET\"\n");
			
			httpClient H1 = new httpClient("/maestro/getMailConfig?groupName="+group,"GET","","", true);
			mailGrpResponse = H1.httpRequest();
			
			consoleLog.log("(Thread Process) Response:"+json_pretty_print(mailGrpResponse)+"\n");
			System.out.println("(Thread Process) Response:"+json_pretty_print(mailGrpResponse)+"\n");
			if((mailGrpResponse != null) && (!mailGrpResponse.isEmpty()) && (!mailGrpResponse.equals("")))	
			{
				Object obj = new JSONParser().parse(mailGrpResponse);
				JSONObject jo = (JSONObject) obj;
				
				String mailIds = (String) jo.get("userEmailIds");
	     			
				if(subject.equals("DB") || ((mailGrpResponse.equals(""))))
				{
					//API server error
					//sendMail("Net-ops","ERROR","DB","","");
					if(new File("maestroqs_support.json").exists())
					{
						String mailIdJson = U1.fileRead("maestroqs_support.json");
						if ((mailIdJson != null) && (!mailIdJson.isEmpty()) && (!mailIdJson.equals(""))) 
						{
							JSONParser parser = new JSONParser();
							Object preEditObj = parser.parse(mailIdJson);
							jo = (JSONObject) preEditObj;
							mailIds = (String) jo.get("mail_id");
		
							consoleLog.log("(Thread Process offline) mail_ids:"+mailIds+"\n");
							System.out.println("(Thread Process offline) mail_ids:"+mailIds+"\n");
							
						}
					}
					else 
					{
						consoleLog.log("JSON Parse failed for JSON on maestroqs_support.json\n\n");
						System.out.println("JSON Parse failed for JSON on maestroqs_support.json");
						
						mailIds = "rajarajan@codemantra.in";
						
						//return;
					}
				}
				consoleLog.log("(Thread Process) mail_ids:"+mailIds+",\n");
				System.out.println("(Thread Process) mail_ids:"+mailIds+",\n");
				
				if((subject.equals("DB")&& status.equals("ERROR")) || (subject.equals("MOUNT") && status.equals("ERROR")))
					subject = "NETWORK - ERROR";
				else
				{
					if(status.equals("JOB_SUCCESS"))
						subject = subject+" - SUCCESS";
					else if(status.equals("JOB_FAIL") || status.equals("API") || status.equals("STYLESHEET") || status.equals("DIRECTORY") || status.equals("TEMPLATE ERROR"))
						subject = subject+" - ERROR";
					else
						subject = subject+" - "+status;
				}
				
				String mailMessage = "";
		        switch(URLDecoder.decode(group, "UTF-8"))
		        {
			        case "Template":
		        		if(status.equals("ERROR"))
		        		{
		        			if(!attachment.isEmpty())
		        			{
				        		mailMessage = "Dear All,\n\n"+
											subject+"\n" +
										"--------------------------------------------\n\n" +
						 				"Please find the attached error log and clear the listed errors within the InDD Template and Import Map respectively.\n\n" +
						 				"After clearing the error[s], the above error log need to be uploaded into Maestro Queuing System through \"cM_Tools->Comp->T&F->MaestroQS->InDT/IIMap Certification\".\n\n" +
						 				"\nThanks & Regards,\n" +
						 				"Maestro Queuing System";
		        			}
		        			else
		        			{
		        				mailMessage = "Dear All,\n\n"+
										subject+"\n" +
									"--------------------------------------------\n\n" +
									errParam + "\n\n" +
					 				"\nThanks & Regards,\n" +
					 				"Maestro Queuing System";
		        			}
		        		}
		        		else if(status.equals("TEMPLATE ERROR"))
		        		{
		        			mailMessage = "Dear All,\n\n"+
									subject+"\n" +
								"--------------------------------------------\n\n" +
								errParam + "\n\n" +
				 				"\nThanks & Regards,\n" +
				 				"Maestro Queuing System";
		        		}
		        		else if(status.equals("SUCCESS"))
		        		{
		        			mailMessage = "Dear All,\n\n"+
									subject+"\n" +
								"--------------------------------------------\n\n" +
				 				"The file is ready for Maestro IDML process.\n\n" +
				 				"\nThanks & Regards,\n" +
				 				"Maestro Queuing System";
		        		}
		        		else if(status.equals("JOB_SUCCESS"))
		        		{
		        			mailMessage = "Dear All,\n\n"+
									subject+"\n" +
								"--------------------------------------------\n\n" +
								"This job is completed successfully.\n\n" +
								errParam + "/"+ errParam +" manuscript[s] has been posted for Maestro IDML process.\n\n" +
				 				"\nThanks & Regards,\n" +
				 				"Maestro Queuing System";
		        		}
		        		else if(status.equals("JOB_FAIL"))
		        		{
		        			mailMessage = "Dear All,\n\n"+
									subject+"\n" +
		        				"--------------------------------------------\n\n" +
				 				"This Job feed has failed and it has the following error[s].\n" +
				 				errParam +
				 				"\nPlease review and re-feed the Job into Maestro Queuing System.\n\n" +
				 				"\nThanks & Regards,\n" +
				 				"Maestro Queuing System";
		        		}
		        		break;
		        		
		        	case "Net-ops":
		        		if(subject.equals("MOUNT"))
		        		{
		        			if(status.equals("ERROR"))
		        			{
			        			mailMessage = "Dear Team,\n\n" +
			        						//"--------------------------------------------\n\n" +
			        						"MaestroQS has failed to mount the following server share[s] "+errParam+" within the system.\n\n" +
			        					   	"Please check and do the needful promptly.\n\n" +
			        					   	"\nThanks & Regards,\n" +
			        					   	"Maestro Queuing System";
		        			}
		        			else if(status.equals("SUCCESS"))
		        			{
		        				mailMessage = "Dear Team,\n\n" +
		        						//"--------------------------------------------\n\n" +
		        						"MaestroQS successfully mount the server share[s] within the system.\n\n" +
		        					   	"\nThanks & Regards,\n" +
		        					   	"Maestro Queuing System";
		        			}
		        		}
		        		else if(subject.equals("DB"))
		        		{
		        			if(status.equals("ERROR"))
		        			{
			        			mailMessage = "Dear Team,\n\n" +
			        						//"--------------------------------------------\n\n" +
			        						"MaestroQS is failed to connect with (IP: 172.16.1.25) server, it seems the server is \"Offline\".\n\n" +
			        						"Please check and do the needful ASAP.\n\n" +
			        						"\nThanks & Regards,\n" +
			        					   	"Maestro Queuing System";
		        			}
		        			else if(status.equals("SUCCESS"))
		        			{
		        				mailMessage = "Dear Team,\n\n" +
		        						//"--------------------------------------------\n\n" +
		        						"MaestroQS can able to connect with (IP: 172.16.1.25) Server, it seems the Server is back \"Online\".\n\n" +
		        						"\nThanks & Regards,\n" +
		        					   	"Maestro Queuing System";
		        			}
		        		}
		        		break;
		        		
		        	case "Pre-editing":
		        	case "TF_Mono":
		        	case "TF_TS":
		        	case "TF_PM":
		        	case "TF_LAW":
		        	case "TF_MW":
		        	case "TF_SPIB":
		        	case "TF_STEM":
		        	case "TF_Encyclopedia":
		        		if(status.equals("API"))
		        		{
			        		mailMessage = "Dear All,\n\n"+
										subject+"\n" +
										"--------------------------------------------\n\n" +
										"The file has not completed/passed all the Content-Modelling stages.\n\n" +
										"Please check and repost the file through Content-Modelling System.\n\n" +
										"\nThanks & Regards,\n" +
										"Maestro Queuing System";
			        	}
		        		else if(status.equals("STYLESHEET"))
		        		{
			        		mailMessage = "Dear All,\n\n"+
										subject+"\n" +
										"--------------------------------------------\n\n" +
										"The stylesheet file for \""+subject+"\" is missing.\n\n" +
										"Please check and repost the file through Content-Modelling System.\n\n" +
										"\nThanks & Regards,\n" +
										"Maestro Queuing System";
			        	}
		        		else if(status.equals("INVALID"))
		        		{
			        		mailMessage = "Dear All,\n\n"+
										subject+"\n" +
										"--------------------------------------------\n\n" +
										"The invalid file / folder ("+errParam+") posted by the user for this Job.\n\n" + 
										"Please follow the MaestroQS guidelines.\n\n" +
										//"This file("+errParam+") is invalid for the Job :\""+subject+"\".\n\n" +
										//"Please check and repost the file through Content-Modelling module.\n\n" +
										"\nThanks & Regards,\n" +
										"Maestro Queuing System";
			        	}
		        		else if(status.equals("JOB_FAIL"))
		        		{
		        			mailMessage = "Dear All,\n\n"+
								subject+"\n" +
		        				"--------------------------------------------\n\n" +
				 				"This Job feed has failed and it has the following error[s].\n" +
				 				errParam +
				 				"\nPlease review and re-feed the Job into Maestro Queuing System.\n\n" +
				 				"\nThanks & Regards,\n" +
				 				"Maestro Queuing System";
		        		}
		        		else if(status.equals("DIRECTORY"))
		        		{
		        			mailMessage = "Dear All,\n\n"+
									subject+"\n" +
								"--------------------------------------------\n\n" +
				 				"MaestroQS failed to locate the \"Equations\\"+subject+"\" folder for this chapter in the \"MaestroReady\" folder.\n\n" +
				 				"\nThanks & Regards,\n" +
				 				"Maestro Queuing System";
		        		}
		        		else if(status.equals("ERROR"))
		        		{
		        			if(!attachment.isEmpty())
		        			{
				        		mailMessage = "Dear All,\n\n"+
											subject+"\n" +
										"--------------------------------------------\n\n" +
						 				"Please find the attached error log and clear the listed errors within the InDD Template and Import Map respectively.\n\n" +
						 				"After clearing the error[s], the above error log need to be uploaded into Maestro Queuing System through \"cM_Tools->Comp->T&F->MaestroQS->InDT/IIMap Certification\".\n\n" +
						 				"\nThanks & Regards,\n" +
						 				"Maestro Queuing System";
		        			}
		        			else
		        			{
		        				mailMessage = "Dear All,\n\n"+
										subject+"\n" +
									"--------------------------------------------\n\n" +
					 				"The Used stylesheet file for this manuscript is Invalid.\n\n" +
					 				"\nThanks & Regards,\n" +
					 				"Maestro Queuing System";
		        			}
		        		}
		        		break;
		        		
		        	case "CRC Team":
		        		if(status.equals("JOB_FAIL"))
		        		{
		        			mailMessage = "Dear All,\n\n"+
								subject+"\n" +
		        				"--------------------------------------------\n\n" +
				 				"This Job feed has failed and it has the following error[s].\n" +
				 				errParam +
				 				"\nPlease review and re-feed the Job into Maestro Queuing System.\n\n" +
				 				"\nThanks & Regards,\n" +
				 				"Maestro Queuing System";
		        		}
		        		else if(status.equals("ERROR"))
		        		{
		        			if(!attachment.isEmpty())
		        			{
				        		mailMessage = "Dear All,\n\n"+
											subject+"\n" +
										"--------------------------------------------\n\n" +
						 				"Please find the attached error log and clear the listed errors within the InDD Template and Import Map respectively.\n\n" +
						 				"After clearing the error[s], the above error log need to be uploaded into Maestro Queuing System through \"cM_Tools->Comp->T&F->MaestroQS->InDT/IIMap Certification\".\n\n" +
						 				"\nThanks & Regards,\n" +
						 				"Maestro Queuing System";
		        			}
		        			else
		        			{
		        				mailMessage = "Dear All,\n\n"+
										subject+"\n" +
									"--------------------------------------------\n\n" +
					 				"The Used stylesheet file for this manuscript is Invalid.\n\n" +
					 				"\nThanks & Regards,\n" +
					 				"Maestro Queuing System";
		        			}
//			        			mailMessage = "Dear All,\n\n"+
//										subject+"\n" +
//									"--------------------------------------------\n\n" +
//					 				"Please find the attached error log and clear the listed errors within the InDD Template and Import Map respectively.\n\n" +
//					 				"After clearing the erro[s], the above error log need to be uploaded into Maestro Queuing System through \"cM_Tools->Comp->T&F->MaestroQS->InDT/IIMap Certification\".\n\n" +
//					 				"\nThanks & Regards,\n" +
//					 				"Maestro Queuing System";
		        		}
		        		else if(status.equals("SUCCESS"))
		        		{
		        			mailMessage = "Dear All,\n\n"+
									subject+"\n" +
								"--------------------------------------------\n\n" +
				 				"The file is ready for Maestro IDML process.\n\n" +
				 				"\nThanks & Regards,\n" +
				 				"Maestro Queuing System";
		        		}
		        		else if(status.equals("DIRECTORY"))
		        		{
		        			mailMessage = "Dear All,\n\n"+
									subject+"\n" +
								"--------------------------------------------\n\n" +
				 				"MaestroQS failed to locate the Job folder ("+errParam+") in the following server share[s] within the system (IP:172.16.4.184).\n\n" +
				 				"\nThanks & Regards,\n" +
				 				"Maestro Queuing System";
		        		}
		        		break;
		        		
		        	case "Graphics":
		        		if(status.equals("JOB_FAIL"))
		        		{
		        			mailMessage = "Dear All,\n\n"+
								subject+"\n" +
		        				"--------------------------------------------\n\n" +
				 				"This Job feed has failed and it has the following error[s].\n" +
				 				errParam +
				 				"\nPlease review and re-feed the Job into Maestro Queuing System.\n\n" +
				 				"\nThanks & Regards,\n" +
				 				"Maestro Queuing System";
		        		}
		        		break;
		        }
				
		        /*{
			    	"groupName": "Test",
			    	"mailcc": "rajkannan@codemantra.com",
			    	"subject": "Maestro API Email",
			    	"message": "Maestro API email testing"
		    	}*/
		        JSONObject obj1=new JSONObject();
		        //obj1.put("groupName",URLDecoder.decode(group,"UTF-8"));
		        obj1.put("fromMailIds","maestroqs@codemantra.in");
		        obj1.put("toMailIds",mailIds);
		        obj1.put("mailCc","rajarajan@codemantra.in");
		        obj1.put("subject",subject);
		        obj1.put("message",mailMessage);
		        
		        String jsonText = JSONValue.toJSONString(obj1);
		        
		        if(attachment.isEmpty())
		        	this.url = "http://"+ serverIp +"/maestro/mail";
		        else
		        	this.url = "http://"+ serverIp +"/maestro/mailAttach";
		        
		        this.jsonData = jsonText;
		        this.fileName = attachment;
		        
		        mailSend();
			}
		}
		
		return mailStatus;
	}
	
	private boolean mailSend() throws ClientProtocolException, IOException, ParseException
	{
		boolean mailStatus = false;
		CloseableHttpClient client = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(url);

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		// builder.addTextBody("username", "John");
		builder.addTextBody("email", this.jsonData);
		if(!this.fileName.isEmpty())
			builder.addBinaryBody("file", new File(this.fileName), ContentType.APPLICATION_OCTET_STREAM, FilenameUtils.getName(this.fileName));

		HttpEntity multipart = builder.build();
		httpPost.setEntity(multipart);

		String response = "";

		// CloseableHttpResponse response = client.execute(httpPost);
		// System.out.println("response:" + response.getStatusLine().getStatusCode());
		try (CloseableHttpResponse httpResponse = client.execute(httpPost))
		{
			HttpEntity httpEntity = httpResponse.getEntity();
			response = EntityUtils.toString(httpEntity);
			EntityUtils.consume(httpEntity);

			System.out.println("response:" + response);
			JSONParser parser = new JSONParser();
			Object responseObj = parser.parse(response);

			JSONObject jo = (JSONObject) responseObj;
			String status = (String) jo.get("status");
			String mailIds = (String) jo.get("mailIds");

			System.out.println("status:" + status);
			if (status.equals("FOUND"))
			{
				System.out.println("mailIds:" + mailIds);
				mailStatus = true;
			}

		}
		catch (IOException e)
		{
			// e.printStackTrace();
		}
		client.close();
		return mailStatus;
	}
}
