package folder_watcher;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
//import java.util.Set;
import java.util.concurrent.TimeUnit;

public class xmlPrj
{
	boolean crTrans(String transPath, String chapter) throws Exception
	{
		try
		{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.newDocument();
			//doc.getDocumentElement().normalize();
			doc.setXmlStandalone(true);
			
			// root element
			Element rootElement = doc.createElement("transformationjob");
			doc.appendChild(rootElement);

			// supercars element
			Element params = doc.createElement("parameters");
			rootElement.appendChild(params);

			String arr[] = { "Document", "InputFile", "ResultFile" };
			for (int i = 0; i < 3; i++)
			{
				// carname element
				Element s1 = doc.createElement("Symbol");
				Attr attrName = doc.createAttribute("name");
				Attr attrValue = doc.createAttribute("value");

				attrName.setValue(arr[i]);
				attrValue.setValue(chapter);

				s1.setAttributeNode(attrName);
				s1.setAttributeNode(attrValue);

				s1.appendChild(doc.createTextNode(""));
				params.appendChild(s1);
			}

			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);

			// Output to console for testing
			//StreamResult consoleResult = new StreamResult(System.out);
			StreamResult result = new StreamResult(new File(transPath));
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			//transformer.transform(source, consoleResult);
			transformer.transform(source, result);
		}
		catch (Exception e)
		{
			return false;
			// throw e;
			// e.printStackTrace();
		}
		return true;
	}

	/*public static void main(String argv[]) throws Exception
	{
		xmlPrj x1 = new xmlPrj();
		//File transForm = new File("transformation.xml");
		//if (!transForm.exists())
		{
			//x1.crTrans("Chapter_03");
		}
		//else
		{
			//x1.upTrans("Chapter_03");
			//x1.upMprj("TFCRCBM.mprj","Kondensed_ID9_B_P95_C1_BM");
		}

	}*/

	void upTrans(String transPath,String chapter) throws Exception
	{
		File inputFile = new File(transPath);
		//System.out.println(inputFile.exists());
		if(!inputFile.exists())
		{
			//System.out.println("Transformation.xml not exists.\n");
			crTrans(transPath, chapter);
			TimeUnit.SECONDS.sleep(1);
		}
		try
		{
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(inputFile);
			//doc.getDocumentElement().normalize();
			NodeList nodeList = doc.getElementsByTagName("Symbol");			
			Map< String,String> hm = new HashMap< String,String>();
			String arr[] = { "Document", "InputFile", "ResultFile" };
			for (int i = 0; i < nodeList.getLength(); i++)
			{
				Element e = (Element)nodeList.item(i);
				String name = e.getAttribute("name");
				String value = e.getAttribute("value");
				hm.put(name, value);
				e.setAttribute("name", arr[i]);
				e.setAttribute("value", chapter);
			}
			
			/*Set< Map.Entry< String,String> > st = hm.entrySet();    
			for (Map.Entry< String,String> me:st) 
			{ 
				System.out.print(me.getKey()+":"); 
			    System.out.println(me.getValue()); 
			} */
			//String arr[] = { "Document", "InputFile", "ResultFile" };

			// System.out.println("symName : "+symName.getNodeValue());
			// System.out.println("symName : "+symtype.getNodeValue());

			/*
			 * for(int i=0; i < 3; i++) { //symName }
			 */
			// loop the supercar child node
			// NodeList list = supercar.getChildNodes();
			/*
			 * for (int temp = 0; temp < list.getLength(); temp++) { Node node =
			 * list.item(temp); if (node.getNodeType() == Node.ELEMENT_NODE) { Element
			 * eElement = (Element) node; if ("carname".equals(eElement.getNodeName())) {
			 * if("Ferrari 101".equals(eElement.getTextContent())) {
			 * eElement.setTextContent("Lamborigini 001"); }
			 * if("Ferrari 202".equals(eElement.getTextContent()))
			 * eElement.setTextContent("Lamborigini 002"); } } }
			 */

			
			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);

			// Output to console for testing
			//StreamResult consoleResult = new StreamResult(System.out);
			StreamResult result = new StreamResult(new File(transPath));
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			//transformer.transform(source, consoleResult);
			transformer.transform(source, result);
			 
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	void upMprj(String mprjPath, String tempL) throws Exception
	{
		try
		{
			System.out.println("mprjPath:"+mprjPath);
			System.out.println("tempL:"+tempL);
			if(new File(mprjPath).exists())
			{
				File inputFile = new File(mprjPath);
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.parse(inputFile);
				doc.getDocumentElement().normalize();
				//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	            //NodeList nodeList = doc.getElementsByTagName("Command");
				NodeList nodeList = doc.getElementsByTagName("Document");
				
				for (int i = 0; i < nodeList.getLength(); i++)
				{
					Node e = nodeList.item(i);
					if (e.getNodeType() == Node.ELEMENT_NODE)
					{
						//System.out.println(name);
						//System.out.println(name);
						Element element = (Element) nodeList.item(i);
						NodeList nodeList1 = element.getElementsByTagName("Type").item(0).getChildNodes();
						Node node = (Node) nodeList1.item(0);
				        //System.out.println(node.getNodeValue());
				        if(node.getNodeValue().equalsIgnoreCase("Template"))
				        {
				        	//System.out.println(node.getNodeValue());
				        	nodeList1 = element.getElementsByTagName("FileName").item(0).getChildNodes();
							node = (Node) nodeList1.item(0);
							//System.out.println(node.getNodeValue());
							
							node.setNodeValue(tempL);
				        }
					}
					//String value = e.getAttribute("value");
					//hm.put(name, value);
					//e.setAttribute("name", arr[i]);
					//e.setAttribute("value", chapter);
				}
				
				
				/*Map< String,String> hm = new HashMap< String,String>();
				String arr[] = { "Document", "InputFile", "ResultFile" };
				for (int i = 0; i < nodeList.getLength(); i++)
				{
					Element e = (Element)nodeList.item(i);
					String name = e.getAttribute("name");
					String value = e.getAttribute("value");
					hm.put(name, value);
					e.setAttribute("name", arr[i]);
					//e.setAttribute("value", chapter);
				}
				
				Set< Map.Entry< String,String> > st = hm.entrySet();    
				for (Map.Entry< String,String> me:st) 
				{ 
					System.out.print(me.getKey()+":"); 
				    System.out.println(me.getValue()); 
				} */
				
				
				
				// write the content into xml file
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
		
				// Output to console for testing
				//StreamResult consoleResult = new StreamResult(System.out);
				StreamResult result = new StreamResult(new File(mprjPath));
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
				//transformer.transform(source, consoleResult);
				transformer.transform(source, result);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	Boolean upInddMap(String fileName, String template)  throws Exception
	{
		Boolean status = false;
		
		if(new File(fileName).exists())
		{
			//crTrans(chapter);
			
			try
			{
				File inputFile = new File(fileName);
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.parse(inputFile);
				doc.getDocumentElement().normalize();
				//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
				
				NodeList nodeList = doc.getElementsByTagName("UseArg");
				//System.out.println("length:"+nodeList.getLength());
				for (int i = 0; i < nodeList.getLength(); i++)
				{
					Node e = nodeList.item(i);
					//System.out.println(e.getTextContent());
					e.setTextContent(template+"_FM_OTH");
					/*if (e.getNodeType() == Node.ELEMENT_NODE)
					{
						e.setNodeValue("_FM_OTH");
					}*/
				}
				// write the content into xml file
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
		
				// Output to console for testing
				//StreamResult consoleResult = new StreamResult(System.out);
				StreamResult result = new StreamResult(new File(fileName));
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
				//transformer.transform(source, consoleResult);
				transformer.transform(source, result);
			}
			catch(Exception e)
			{
				
			}
		}
		return status;
	}
}

