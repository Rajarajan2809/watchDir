package folder_watcher;

/*
 * Copyright (c) 2008, 2010, Oracle and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Oracle nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
//https://docs.oracle.com/javase/tutorial/essential/io/notification.html
import java.nio.file.*;
import static java.nio.file.StandardWatchEventKinds.*;
//import static java.nio.file.LinkOption.*;
//import java.nio.file.attribute.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.io.*;
import java.net.URLEncoder;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

//import javax.script.ScriptEngine;
//import javax.script.ScriptEngineManager;

//import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.*;

//import folder_watcher.mail;
//import folder_watcher.url_request;

//import org.apache.poi.ooxml.POIXMLDocument;
//import org.apache.poi.xwpf.usermodel.XWPFDocument;

/*
 * try
	mount volume "smb://rajarajan:Amma2809appa_@172.16.1.2/OEO/"
end try

	try
	
	mount volume "smb://172.16.1.2/Copyediting/" as user name "maestroqs@cmpl.in" with password "M@est0123"
	
end try

 * 
 */
/**
 * Example to watch a directory (or tree) for changes to files.
 */
public class watchDir implements Runnable
{
    private final WatchService watcher;
    private final Map<WatchKey,Path> keys;
    private final Map<String,String> jobParam;
    private boolean trace = false;
    private final AtomicInteger counter;
    private int processedFiles = 0;
    private String pathString, noOfManuScripts, jobId;
	private final String clientId;
	private String templatePath,styleSheetPath,importMapPath,templateName,templateType;
    private ArrayList<String> manuScripts;
    //mail mailObj;
    private job j1 = new job();
    private httpClient H1;
    private utilities U1 = new utilities();
    boolean suspended = false;
	//private XWPFDocument docx;
    
    @SuppressWarnings("unchecked")
    static <T> WatchEvent<T> cast(WatchEvent<?> event) 
    {
        return (WatchEvent<T>)event;
    }

    private void register(Path dir) throws IOException 
    {
        WatchKey key = dir.register(watcher, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);
        if (trace) 
        {
            Path prev = keys.get(key);
            if (prev == null)
            {
                System.out.format("register: %s\n", dir);
            }
            else 
            {
                if (!dir.equals(prev)) 
                {
                    System.out.format("update: %s -> %s\n", prev, dir);
                }
            }
        }
        keys.put(key, dir);
    }

    watchDir(Map <String,String> jobParam,AtomicInteger counter) throws IOException, ParseException, NumberFormatException 
    {
        this.watcher = FileSystems.getDefault().newWatchService();
        this.keys = new HashMap<WatchKey,Path>();
        this.jobParam = jobParam;
        pathString = jobParam.get("Copyediting");
        clientId = jobParam.get("clientId");
        jobId = jobParam.get("jobId");
        noOfManuScripts = jobParam.get("manuscripts");
        templatePath = jobParam.get("Template");
        styleSheetPath = jobParam.get("Standard_stylesheet");
        importMapPath = jobParam.get("Map_path");
        templateName = jobParam.get("templateName");
        templateType = jobParam.get("templateType");
        this.counter = counter;
        Path listPath;
        manuScripts = new ArrayList<String>();
        listPath = Paths.get(pathString);
        register(listPath);
        this.trace = true;
    }

    private void initProcessing() throws Exception
    {
    	File folder = new File(pathString);
        File[] listOfFiles = folder.listFiles();
        
        System.out.println("Processing already present files in Job folder...\n");
		consoleLog.log("Processing already present files in Job folder...\n");
		if(folder.exists())
		{
			for (int i = 0; i < listOfFiles.length; i++) 
			{
				if(processedFiles < Integer.parseInt(noOfManuScripts))
				{
					if (listOfFiles[i].isFile()) 
					{
						System.out.println("Extension:"+U1.getFileExtension(listOfFiles[i]));
						System.out.println("File/Folder Status:"+listOfFiles[i].isFile());
						
						//String REGEX = jobId+"_PT\\d\\d|"+jobId+"_ST\\d\\d|"+jobId+"_FM\\d\\d|"+jobId+"_BM\\d\\d|"+jobId+"_RM\\d\\d|"+jobId+"_CH\\d\\d|"+jobId+"_INTRO|"+jobId+"_CON|"+jobId+"_APP\\d\\d|";
						
						//regex matching
						//Pattern p = Pattern.compile(REGEX);
						//Matcher m = p.matcher(U1.getFileNameWithoutExtension(listOfFiles[i]));   // get a matcher object
		    				
						if(fileNameRegex(jobId,listOfFiles[i]) && (listOfFiles[i].getName().lastIndexOf(".docx") > 0))
						{
							//System.out.println("File " + listOfFiles[i].getName());
							
							if(!manuScripts.contains(listOfFiles[i].getName()))
							{
								try 
				        		{
									while(!isCompletelyWritten(listOfFiles[i]))
									{}
								}
				        		catch (InterruptedException e) 
				        		{}
								
								functionalityCheck(listOfFiles[i].getName());
							}
						}
						else if(fileNameRegex(jobId,listOfFiles[i]) && (listOfFiles[i].getName().lastIndexOf(".xlsx") > 0))
						{
							System.out.println("xlsx file created at "+listOfFiles[i].getName());
		    				consoleLog.log("xlsx file created at "+listOfFiles[i].getName()+"\n");
		    				
		    				if(!U1.fileCheck(pathString +listOfFiles[i].getName()))
		    				{
		    					System.out.println("Manuscript not found, hence moved to \"ERROR\" folder");
		        				consoleLog.log("Manuscript not found, hence moved to \"ERROR\" folder");
		        				
		        				U1.fileMove(pathString+listOfFiles[i].getName(),pathString+"ERROR/"+listOfFiles[i].getName());
		    				}
						}
						else if(!listOfFiles[i].getName().equals(".DS_Store"))
						{
							//invalid other format files
				        	File theDir = new File(pathString+"INVALID_FILES/");
				        	if (!theDir.exists()) 
							{
				        		theDir.mkdir();
							}
				        	U1.fileMove(pathString+listOfFiles[i].getName(),pathString+"INVALID_FILES/"+listOfFiles[i].getName());
							
				        	//H1.mailConstruct("Pre-editing", "INVALID", jobId, "", listOfFiles[i].getName());
				        	if(H1.mailConstruct(templateType, "INVALID", jobId, "", listOfFiles[i].getName()))
			        			System.out.println("Mail to \""+templateType+"\" for "+listOfFiles[i].getName()+" sent successfully at "+U1.getLocalTime());
			        		else
			        			System.out.println("Mail to \""+templateType+"\" for "+listOfFiles[i].getName()+" sending failed at "+U1.getLocalTime());
				        	/*mailObj = new mail("Pre-editing", "INVALID", jobId, "", listOfFiles[i].getName());
							Thread mailThread6 = new Thread(mailObj, "Mail Thread for Pre editing Team");
				        	mailThread6.start();*/
				        	
							//xlsx and docx files does not match regex
							System.out.println("Waiting for more files1...");
							consoleLog.log("Waiting for more files1...");
						}
					}
					else if (listOfFiles[i].isDirectory()) 
					{
						//Move manuscripts to error folder
						if(!(listOfFiles[i].getName().compareToIgnoreCase("ERROR") == 0) && !(listOfFiles[i].getName().compareToIgnoreCase("INVALID_FILES") == 0) && !(listOfFiles[i].getName().compareToIgnoreCase("Equations") == 0))
			        	{
							File theDir = new File(pathString+"INVALID_FILES/");
			        	
				        	if (!theDir.exists()) 
							{
				        		theDir.mkdir();
							}
				        	U1.recurMove(new File(pathString+listOfFiles[i].getName()), new File (pathString+"INVALID_FILES/"+listOfFiles[i].getName()));
							
				        	if(H1.mailConstruct(templateType, "INVALID", jobId, "", listOfFiles[i].getName()))
			        			System.out.println("Mail to \""+templateType+"\" for "+listOfFiles[i].getName()+" sent successfully at "+U1.getLocalTime());
			        		else
			        			System.out.println("Mail to \""+templateType+"\" for "+listOfFiles[i].getName()+" sending failed at "+U1.getLocalTime());
				        	/*mailObj = new mail("Pre-editing", "INVALID", jobId, "", listOfFiles[i].getName());
							Thread mailThread6 = new Thread(mailObj, "Mail Thread for Pre editing Team");
				        	mailThread6.start();*/
				        	
				        	System.out.println("Waiting for more files2...");
							consoleLog.log("Waiting for more files2...");
			        	}
						//xlsx and docx files does not match regex
					}
				}
				else
					return;
			}
		}
    }
    
    /**
     * Process all events for keys queued to the watcher
     * @throws Exception 
     */
    int processEvents() throws Exception
    {
    	boolean initFlag = false;
    	
		for (;;) 
        {
			if(initFlag == false)
        	{
        		try 
        		{
					initProcessing();
				}
        		catch (InterruptedException e) 
        		{
					// TODO Auto-generated catch block
					//e.printStackTrace();
				}
        		initFlag = true;
        		
        		//template path or stylesheet path or map path is missing
        		System.out.println("jobId:"+jobId);
        		System.out.println("clientId:"+clientId);
        		/*if(jobFailErrorFun())
				{
					return 1;
				}*/
        	}	
    		if(processedFiles == Integer.parseInt(noOfManuScripts))
            {
				//if other docx files present
            	if(manuScripts.size() == Integer.parseInt(noOfManuScripts))
            	{
            		
            		//System.out.println("Job terminated due to TemplatePath or mapPath or styleSheetPath location missing or incorrect.");
            		//consoleLog.log("Job terminated due to TemplatePath or mapPath or styleSheetPath location missing or incorrect.");
            	}
            	System.out.println("Job finished.\n");
				consoleLog.log("Job finished.\n");
        		return 2;
            }
        		
    		//this prints when job started watching folder
    		//System.out.println("Watch Folder initiated......\n");
			//consoleLog.log("Watch Folder initiated......\n");
        	//pre change check
        	/*if(processedFiles == Integer.parseInt(noOfManuScripts))
            {
        		return 3;
        		//if(getExtension(pathString,".docx").length == Integer.parseInt(noOfManuScripts))
        			//break;
            }*/
            // wait for key to be signaled
            WatchKey key;
            try 
            {
                key = watcher.take();
            }
            catch (InterruptedException x) 
            {
                return 4;
            }

            Path dir = keys.get(key);
            if (dir == null) 
            {
                System.err.println("WatchKey not recognized!!");
                continue;
            }
            
            for (WatchEvent<?> event: key.pollEvents()) 
            {
            	//System.out.println("new element:"+listA.size());
            	//if(listA.size() == 3)
            		//System.out.println("new element:"+listA.get(2));
            	
                @SuppressWarnings("rawtypes")
				WatchEvent.Kind kind = event.kind();

                // TBD - provide example of how OVERFLOW event is handled
                if (kind == OVERFLOW) 
                {
                	continue;
                }

                // Context for directory entry event is the file name of entry
                WatchEvent<Path> ev = cast(event);
                Path name = ev.context();
                Path child = dir.resolve(name);
                
                try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) 
                {
                    /*for (Path file: stream) 
                    {
                        System.out.println(file.getFileName());
                    }*/
                } catch (IOException | DirectoryIteratorException x) {
                    // IOException can never be thrown by the iteration.
                    // In this snippet, it can only be thrown by newDirectoryStream.
                    System.err.println(x);
                }
                
                // print out event
                if((kind == ENTRY_CREATE) || (kind == ENTRY_DELETE) || (kind == ENTRY_MODIFY))
                {
                	//int i = child.getFileName().toString().lastIndexOf('.');
                	//String extension="";
                	//if (i > 0) 
                	//{
                		//extension = child.getFileName().toString().substring(i+1);
                	//}
                	
                	//System.out.println(child.getFileName().toString());
                		
            		if(kind == ENTRY_CREATE)
            		{
            			File createdFile = child.toFile();
            			//System.out.println(pathString + "/" + child.getFileName().toString());
//            			System.out.println("Extension:"+utilities.getFileExtension(createdFile));
//            			System.out.println("File/Folder Status:"+createdFile.isFile());
            			
            			if(createdFile.isFile())
            			{
            				//String fileNameWoExtn = utilities.getFileNameWithoutExtension(createdFile);
                			//System.out.println(child.getFileName().toString()+" is a file.");
                			//System.out.println("Extension: "+extension);
            				//String REGEX = jobId+"_PT\\d\\d|"+jobId+"_ST\\d\\d|"+jobId+"_FM\\d\\d|"+jobId+"_BM\\d\\d|"+jobId+"_RM\\d\\d|"+jobId+"_CH\\d\\d|"+jobId+"_INTRO|"+jobId+"_CON|"+jobId+"_APP\\d\\d|";
            				
            				//regex matching
            				//Pattern p = Pattern.compile(REGEX);
            				//Matcher m = p.matcher(fileNameWoExtn);   // get a matcher object
            				
            				System.out.println("Manuscript name match:"+fileNameRegex(jobId,createdFile)+" for "+createdFile.toString());
            				consoleLog.log("Manuscript name match:"+fileNameRegex(jobId,createdFile)+"\n");
            				
            				try 
			        		{
								while(!isCompletelyWritten(createdFile))
								{}
							}
			        		catch (InterruptedException e) 
			        		{
								// TODO Auto-generated catch block
								//e.printStackTrace();
							}
            				
	            			if(fileNameRegex(jobId,createdFile) && (U1.getFileExtension(createdFile).equals("docx") || U1.getFileExtension(createdFile).equals("xlsx")))
	                    	{
	            				if(fileNameRegex(jobId,createdFile) && U1.getFileExtension(createdFile).equals("docx"))
	            				{
		            				//System.out.print("Docx file created at ");
		            				//System.out.format("%s\n", child);
		            				//consoleLog.log("Docx file created at "+child+"\n");
		            				
		            				//process the manuscript
		            				if(!manuScripts.contains(child.getFileName().toString()))
		        					{
		            					System.out.println("valid file :"+child.getFileName().toString());
			            				consoleLog.log("valid file :"+child.getFileName().toString());
		        						//manuScripts.add(child.getFileName().toString());
		        						functionalityCheck(child.getFileName().toString());
		        					}
		            				else
		            				{
		            					System.out.println("Duplicate Manuscripts file present in Job Folder.\n");
		            					consoleLog.log("Duplicate Manuscripts file present in Job Folder.\n");
		            				}
		            				//System.out.println("jobFailError : "+jobFailErrorFun());
		            				
		            				//template path or stylesheet path or map path is missing
		            				if(processedFiles == Integer.parseInt(noOfManuScripts))
		            	            {
		            					//if other docx files present
		            	            	if(manuScripts.size() == Integer.parseInt(noOfManuScripts))
		            	            	{
		            	            		
		            	            	}
		            	            	System.out.println("Job finished.\n");
		            					consoleLog.log("Job finished.\n");
	            	            		//System.out.println("Job terminated due to TemplatePath or mapPath or styleSheetPath location missing or incorrect.");
	            	            		//consoleLog.log("Job terminated due to TemplatePath or mapPath or styleSheetPath location missing or incorrect.");
	            	            		return 6;
		            	            }
		            			}
	            				else if(fileNameRegex(jobId,createdFile) && U1.getFileExtension(createdFile).equals("xlsx"))
	            				{
	            					System.out.print("xlsx file created at ");
		            				System.out.format("%s\n", child);
		            				consoleLog.log("xlsx file created at "+child+"\n");
		            				
		            				if(!U1.fileCheck(pathString +child.getFileName().toString()))
		            				{
		            					System.out.println("Manuscript not found, hence moved to \"ERROR\" folder");
		                				consoleLog.log("Manuscript not found, hence moved to \"ERROR\" folder");
		                				
		                				U1.fileMove(pathString+child.getFileName().toString(),pathString+"ERROR/"+child.getFileName().toString());
		            				}
	            				}
	                    	}
	            			else if(!createdFile.getName().equals(".DS_Store"))
            				{
	            				System.out.println(child.getFileName().toString()+" is a Invalid file.");
            					//Move manuscripts to error folder
            		        	File theDir = new File(pathString+"INVALID_FILES/");
            		        	if (!theDir.exists()) 
            					{
            		        		theDir.mkdir();
            					}
            		        	U1.fileMove(pathString+child.getFileName().toString(),pathString+"/INVALID_FILES/"+child.getFileName().toString());
            		        	
            		        	
            		        	/*mailObj = new mail("Pre-editing", "INVALID", jobId, "", child.getFileName().toString());
            					Thread mailThread6 = new Thread(mailObj, "Mail Thread for Pre editing Team");
            		        	mailThread6.start();*/
            		        	
            		        	//xlsx and docx files does not match regex
            					System.out.println("Waiting for more files3...");
            					consoleLog.log("Waiting for more files3...");
            				}
            			}
            			else if(new File(pathString + "/" + child.getFileName().toString()).isDirectory())
            			{
            				if(!(child.getFileName().toString().compareToIgnoreCase("ERROR") == 0 )  && !(child.getFileName().toString().compareToIgnoreCase("INVALID_FILES") == 0) && !(child.getFileName().toString().compareToIgnoreCase("Equations") == 0))
            	        	{
	            				//Move manuscripts to error folder
	        		        	File theDir = new File(pathString+"/INVALID_FILES/");
	        		        	if (!theDir.exists()) 
	        					{
	        		        		theDir.mkdir();
	        					}
	        		        	
	        		        	U1.recurMove(new File(pathString+"/"+child.getFileName().toString()), new File(pathString+"/INVALID_FILES/"+child.getFileName().toString()));
	        		        	
	        		        	//H1.mailConstruct("Pre-editing", "INVALID", jobId, "", child.getFileName().toString());
	        		        	if(H1.mailConstruct(templateType, "INVALID", jobId, "", child.getFileName().toString()))
				        			System.out.println("Mail to \""+templateType+"\" for "+child.getFileName().toString()+" sent successfully at "+U1.getLocalTime());
				        		else
				        			System.out.println("Mail to \""+templateType+"\" for "+child.getFileName().toString()+" sending failed at "+U1.getLocalTime());
	        		        	/*mailObj = new mail("Pre-editing", "INVALID", jobId, "", child.getFileName().toString());
	        					Thread mailThread6 = new Thread(mailObj, "Mail Thread for Pre editing Team");
	        		        	mailThread6.start();*/
	        		        	
	        		        	//xlsx and docx files does not match regex
	        					System.out.println("Waiting for more files4...");
	        					consoleLog.log("Waiting for more files4...");
            	        	}
            			}
            		}
            		else if(kind == ENTRY_DELETE)
            		{
            			//System.out.print("File deleted at ");
            			//System.out.format("%s\n", child);
            		}
            		else if(kind == ENTRY_MODIFY)
            		{
            			//System.out.print("File modified at ");
            			//System.out.format("%s\n", child);
            		}
            		//System.out.format("Event:%s\nactivity in	:%s\n", event.kind().name(), child);
                	//String folder = child.toString().substring(0,child.toString().lastIndexOf('/')+1);
                	//System.out.println("folder:"+folder);
                	//System.out.println("folder:"+child.getParent().toString());
                	//System.out.println("file:"+child.getFileName().toString());
                	//System.out.println("file extension:"+extension);
                }
                // if directory is created, and watching recursively, then
                // register it and its sub-directories
//                if (recursive && (kind == ENTRY_CREATE)) 
//                {
//                    try 
//                    {
//                        if (Files.isDirectory(child, NOFOLLOW_LINKS))
//                        {
//                            registerAll(child);
//                        }
//                    } 
//                    catch (IOException x) 
//                    {
//                        // ignore to keep sample readbale
//                    }
//                }
            }
            // reset key and remove from set if directory no longer accessible
            boolean valid = key.reset();
            if (!valid) 
            {
                keys.remove(key);

                // all directories are inaccessible
                if (keys.isEmpty()) 
                {
                    break;
                }
            }
            
            //System.out.println("processedFiles:"+processedFiles);
            //System.out.println("manuscripts:"+noOfManuScripts);
            //post change check 
//            //if(processedFiles == Integer.parseInt(noOfManuScripts))
//            {
//            	//return;
//            	if(getExtension(pathString,".docx").length == Integer.parseInt(noOfManuScripts))
//            		continue;
//            }
        }
        return 7;
    }

	@SuppressWarnings("unchecked")
	@Override
	public void run()
	{
		//boolean procStatus = false;
    	try 
    	{
    			int processStatus;
    			File theDir = new File(pathString+"ERROR/");
    			System.out.println("ERROR folder : "+theDir.toString());
	        	while (!theDir.exists()) 
				{
	        		theDir.mkdir();
				}
        		postValidation postVal = new postValidation(jobParam,counter);
				Thread postValThread = new Thread(postVal, "Watch Thread for \"ERROR\" folder.");
				postValThread.start();
    			job_continue:
    				//infinite loop to connect to disk
    			while(true)
    			{
    					processStatus = processEvents();
	    				System.out.println("processStatus:" + processStatus);
						consoleLog.log("processStatus:" + processStatus);
						//mount error
	    				if(processStatus == 7)
	    				{
	    					suspend();
	    					//TimeUnit.SECONDS.sleep(5);
	    		            //synchronized(this) 
	    		            //{
	    					
	    					System.out.println("Waiting to connect.....\n");
	    					consoleLog.log("Waiting to connect.....\n");
							while(suspended) 
							{
								//wait();
								if(!Main.mountError)
								{
									resume();
								}
								TimeUnit.SECONDS.sleep(1);
							}
							
							if(!new File(pathString).exists())
							{
								DateFormat dateFormat2 = new SimpleDateFormat("dd-MMM-yy hh:mm:ss aa");
								String dateString2 = dateFormat2.format(new Date()).toString();
								System.out.println("Maestro ready folder deleted / renamed at "+dateString2 + ".\n\n");
								consoleLog.log("Maestro ready folder deleted / renamed at "+dateString2 + ".\n\n");
							}
							
							//System.out.println("pathString status:"+!new File(pathString).exists());
							List<String> folderCreate = new ArrayList<>();
							
							folderCreate.add(pathString);
							folderCreate.add(pathString+"ERROR/");
							folderCreate.add(pathString+"Equations/");
							folderCreate.add(pathString+"INVALID_FILES/");
							
							//while(!new File(pathString).exists() || !new File(pathString+"ERROR/").exists() || !new File(pathString+"Equations/").exists())
							for(int j=folderCreate.size()-1; j != -1; j--)
							{
								//System.out.println("Waiting to connect.....");
								TimeUnit.SECONDS.sleep(5);
								
								List<String> folderList = new ArrayList<>();
								String folderThisLoop = folderCreate.get(j);
								//Equations
								while(!new File(folderThisLoop).exists())
			            		{
			            			String folderName = (new File(folderThisLoop)).getName();
			            			folderList.add(folderName);
			            			//System.out.println("parent:"+folderName);
			            			folderThisLoop = (new File(folderThisLoop).getParentFile()).getPath();
			            			//folderList.add(folderName);
			            		}
			            		
			            		for(int i=folderList.size()-1; i != -1; i--)
			            		{
			            			folderThisLoop = folderThisLoop+"/"+folderList.get(i);
			            			File theDir1 = new File(folderThisLoop);
			            			//System.out.println("f1:"+theDir.getPath());
			            			while (!theDir1.exists()) 
			            			{
			                    		theDir1.mkdir();
			            			}
			                    }
								/*theDir = new File(pathString+"Equations/");
				    			//System.out.println("ERROR folder : "+theDir.toString());
					        	while (!theDir.exists()) 
								{
					        		theDir.mkdir();
								}
					        	
					        	//error folder
					        	theDir = new File(pathString+"ERROR/");
				    			//System.out.println("ERROR folder : "+theDir.toString());
					        	while (!theDir.exists()) 
								{
					        		theDir.mkdir();
								}
					        	
					        	//invalid files
					        	theDir = new File(pathString+"INVALID_FILES/");
				    			//System.out.println("ERROR folder : "+theDir.toString());
					        	while (!theDir.exists()) 
								{
					        		theDir.mkdir();
								}*/
							}
							register(Paths.get(pathString));
							System.out.println("Register:"+pathString);
							continue job_continue;
	    		        }
	    				//successful job finish
	    				else
	    					break;
    			}
        		
    			JSONObject obj=new JSONObject();
	    		obj.put("jobId",jobId);
	    		obj.put("clientId",clientId);
	    		
	    		//System.out.println("processError for "+jobId+" :"+processError);
	         	
	         	DateFormat dateFormat2 = new SimpleDateFormat("dd-MMM-yy hh:mm:ss aa");
	        	String dateString2 = dateFormat2.format(new Date()).toString();
	         	
	         	if((processStatus != 7) && (manuScripts.size() == Integer.parseInt(noOfManuScripts)) && (processedFiles == Integer.parseInt(noOfManuScripts)))
	    		{
	         		obj.put("status","COMPLETED");
	    			//JOB successfully finished
	    			//sample : sendMail("Template", "JOB_SUCCESS", "9781138556850_Ilyas", "", noOfManuScripts);
	         		
	         		
	         		if(H1.mailConstruct("Template","JOB_SUCCESS",jobId,"", noOfManuScripts))
	        			System.out.println("Mail to \"Template\" for "+jobId+" sent successfully at "+U1.getLocalTime());
	        		else
	        			System.out.println("Mail to \"Template\" for "+jobId+" sending failed at "+U1.getLocalTime());
	         		/*mailObj = new mail("Template","JOB_SUCCESS",jobId,"", noOfManuScripts);
	    			//mailObj.mailProcess("Template","JOB_SUCCESS","jobId","", "");
	    			Thread mailThread = new Thread(mailObj, "Mail Thread for Job success");
					mailThread.start();*/
	    			
	    			System.out.println("Job finished with SUCCESS at "+dateString2+" for jobId:"+jobId+", clientId:"+clientId+" and folder location:"+pathString);
	             	consoleLog.log("Job finished with success at "+dateString2+" for jobId:\""+jobId+"\", clientId:\""+clientId+"\" and folder location:\""+pathString+"\"");
	             	
//	             	deleting "ERROR" & "INVALID" folder
//	             	utilities.delete(new File(pathString+"/ERROR/"));
//	             	utilities.delete(new File(pathString+"/INVALID/"));
	    		}
	    		/*else
	    		{
	    			//Job failed due to Template path or stylesheet path or map path
	    			obj.put("status","FAILED");
	    			System.out.println("Job finished WITH ERROR at "+dateString2+" for jobId:"+jobId+", clientId:"+clientId+" and folder location:"+pathString);
	             	consoleLog.log("Job finished WITH ERROR at \""+dateString2+"\" for jobId:\""+jobId+"\", clientId:\""+clientId+"\" and folder location:\""+pathString+"\"");
	             	//String jsonText = JSONValue.toJSONString(obj);  
	        		
	//             	consoleLog.log("URL : \"http://"+url_request.serverIp+"/maestro/updateJobStatus\", type : \"PUT\" and content : \""+jsonText+"\"");
	//        		String webResponse = url_request.urlRequestProcess("http://"+url_request.serverIp+"/maestro/updateJobStatus","PUT",jsonText);
	             	
	//        		System.out.println("URL response : "+webResponse);
	//             	consoleLog.log("URL response : "+webResponse);
	    		}*/
	         	
	         	String jsonText = JSONValue.toJSONString(obj);
	    		//System.out.println(jsonText);
	         	//jobStatus update
	         	System.out.println("Job status URL:/maestro/updateJobStatus\", type:\"PUT\" and content:\""+jsonText+"\"");
	         	consoleLog.log("Job status URL:/maestro/updateJobStatus\", type:\"PUT\" and content:\""+jsonText+"\"");   		
	         	H1 = new httpClient("/maestro/updateJobStatus","PUT",jsonText,"",true);
	         	String jobResponse = H1.httpRequest();
	    		
	    		System.out.println("Job status response:"+jobResponse);
	    		consoleLog.log("Job status response:"+jobResponse);
	    		
	         	//j1 = new job();
	         	j1.job_update(jobId);
	         	
	         	if((processStatus == 7) && (manuScripts.size() == Integer.parseInt(noOfManuScripts)) && (processedFiles == Integer.parseInt(noOfManuScripts)))
	    		{
		         	//deleting "ERROR" folder
	             	//utilities.delete(new File(pathString+"/ERROR/"));
	             	//utilities.delete(new File(pathString+"/INVALID_FILES/"));
	    		}
			//}
    	}
    	catch (Exception e) 
    	{
			e.printStackTrace();
//			try 
//			{
//				//consoleLog.log(e.toString());
//			} 
//			catch (IOException e1) 
//			{
//				//e1.printStackTrace();
//			}
		}
    	return;
	}
	
	private boolean functionalityCheck(String file) throws Exception
	{
		//System.out.println("docx path : "+pathString+file); 
		//docx = new XWPFDocument(POIXMLDocument.openPackage(pathString+file));
		//int pages = docx.getProperties().getExtendedProperties().getUnderlyingProperties().getPages();
	    //ystem.out.println("No of pages : "+pages);
		
	    //URLEncoder.encode( jobId, "UTF-8" )
	    //String response = url_request.urlRequestProcess("http://"+url_request.serverIp+"/cs-api/addToolMetrics?toolName=Maestroqs&pageOrImageCount="+pages+"&jobId="+URLEncoder.encode( jobId, "UTF-8" )+"&jobType=Page", "POST", "");
		//System.out.println("response :"+response);
	    
		boolean styleSheetfileStatus = false, contentModellingStatus = false, jsxProcessStatus = false, eqnFolderStatus = false, tempFileStatus = false;// 0 > failed,0 = success
		String chName = file,eqnStatus,preEditStatus,stageCleanUp,docVal,structuringVal,postVal,postConv,inDStyleMap = "",wdExportMap="",templateFile="";
		chName = chName.substring(0,chName.indexOf(".docx"));
		String suffix="";
		//stylesheet for manuscript checking
		if(U1.fileCheck(pathString +"/"+chName+".xlsx"))
		{
			//style sheet present
			System.out.println("Styles file exist for "+chName);
			consoleLog.log("Styles file exist for "+chName);
			styleSheetfileStatus = true;
		}
		else	
		{
			//style sheet missing
			System.out.println("Styles file does not exist for "+file);
			consoleLog.log("Styles file does not exist for "+file);
			
			//sample : sendMail("Pre-editing", "STYLESHEET", "9781138556850_Ilyas_CH01", "", "");
			if(H1.mailConstruct(templateType, "STYLESHEET", chName, "", ""))
				System.out.println("Mail to \""+templateType+"\" for "+chName+" sent successfully at "+U1.getLocalTime());
			else
				System.out.println("Mail to \""+templateType+"\" for "+chName+" sending failed at "+U1.getLocalTime());
			/*mailObj = new mail("Pre-editing", "STYLESHEET", chName, "", "");
			Thread mailThread6 = new Thread(mailObj, "Mail Thread for CRC Team");
        	mailThread6.start();*/
		}
		
		String urlParams = "jobId="+URLEncoder.encode(jobId,"UTF-8")+"&clientId="+URLEncoder.encode(clientId,"UTF-8")+"&chapter="+URLEncoder.encode(chName,"UTF-8");
		consoleLog.log("URL:/maestro/getValStageDetails?"+urlParams + "\", type:\"GET\"\n");
		System.out.println("URL:/maestro/getValStageDetails?"+urlParams + "\", type:\"GET\"\n");
		
		//http://172.16.1.25:8080/maestro/getValStageDetails?jobId=9781482298697_Yu&clientId=TF_HSS&chapter=9781138598928_Willard+Bohn_BM01
		H1 = new httpClient("/maestro/getValStageDetails?"+urlParams,"GET","","",true);
		String preEditResponse = H1.httpRequest();        		
        
    	consoleLog.log("preEditResponse:"+utilities.json_pretty_print(preEditResponse)+"\n");
        System.out.println("preEditResponse:"+utilities.json_pretty_print(preEditResponse)+"\n");
        
        if((preEditResponse != null) && (!preEditResponse.isEmpty()) && (!preEditResponse.equals("")))
		{
        	JSONParser parser = new JSONParser();
			Object preEditObj = parser.parse(preEditResponse);
	        JSONObject jo = (JSONObject) preEditObj;
		    preEditStatus = (String) jo.get("status");
		    stageCleanUp = (String) jo.get("stageCleanUp");
		    docVal = (String) jo.get("docVal");
		    structuringVal = (String) jo.get("structuringVal");
		    postVal = (String) jo.get("postVal");
		    postConv = (String) jo.get("postConv");
		    inDStyleMap = (String) jo.get("inDStyleMap");
		    wdExportMap = (String) jo.get("wdExportMap");
		    
		    //System.out.println("preEditStatus : "+preEditStatus);
		    System.out.println("stageCleanUp : "+stageCleanUp);
		    System.out.println("docVal : "+docVal);
		    System.out.println("structuringVal : "+structuringVal);
		    System.out.println("postVal : "+postVal);
		    System.out.println("postConv : "+postConv);
		    System.out.println("inDStyleMap : "+inDStyleMap);
		    System.out.println("wdExportMap : "+wdExportMap);
		    System.out.println("preEditStatus:"+preEditStatus+"\n"); //+", processError:"+processError
		    
		    consoleLog.log("stageCleanUp : "+stageCleanUp);
		    consoleLog.log("docVal : "+docVal);
		    consoleLog.log("structuringVal : "+structuringVal); 
		    consoleLog.log("postVal : "+postVal);
		    consoleLog.log("postConv : "+postConv);
		    consoleLog.log("inDStyleMap : "+inDStyleMap);
		    consoleLog.log("wdExportMap : "+wdExportMap);
		    consoleLog.log("preEditStatus:"+preEditStatus+"\n"); //+", processError:"+processError
			
			if((stageCleanUp != null) && (!stageCleanUp.isEmpty()) && (stageCleanUp.equals("true")) && 
				(docVal != null) && (!docVal.isEmpty()) && (docVal.equals("true"))  && 
				(structuringVal != null) && (!structuringVal.isEmpty()) && (structuringVal.equals("true"))  && 
				(postVal != null) && (!postVal.isEmpty()) && (postVal.equals("true"))  && 
				(postConv != null) && (!postConv.isEmpty()) && (postConv.equals("true")) && 
				//(inDStyleMap != null) && (!inDStyleMap.isEmpty()) && (inDStyleMap.equals("true")) && 
				(wdExportMap != null) && (!wdExportMap.isEmpty()) && (wdExportMap.equals("true")))
	        {
				//all parameters of content modelling stage true
				contentModellingStatus = true;
	        }
			else
			{
				consoleLog.log("Failed in ContentModelling stage.\n");
	    		System.out.println("Failed in ContentModelling stage.\n");
	    		
	    		//content modelling error
	    		if(H1.mailConstruct(templateType, "API", chName, "", ""))
        			System.out.println("Mail to \""+templateType+"\" for "+chName+" sent successfully at "+U1.getLocalTime());
        		else
        			System.out.println("Mail to \""+templateType+"\" for "+chName+" sending failed at "+U1.getLocalTime());
	    		/*mailObj = new mail("Pre-editing", "API", chName, "", "");
				Thread mailThread6 = new Thread(mailObj, "Mail Thread for CRC Team");
	        	mailThread6.start();*/
			}
		}
        
        if(styleSheetfileStatus && contentModellingStatus )
        {
    		//172.16.4.112:8088/maestro/getChapterEquation?jobId=9781138556850_Ilyas&clientId=TF_STEM&chapter=9781138556850_Ilyas_CH11
        	urlParams = "jobId="+URLEncoder.encode(jobId,"UTF-8")+"&clientId="+URLEncoder.encode(clientId,"UTF-8")+"&chapter="+URLEncoder.encode(chName,"UTF-8");
    		consoleLog.log("URL:/maestro/getChapterEquation?"+urlParams + "\", type:\"GET\"\n");
    		System.out.println("URL:/maestro/getChapterEquation?"+urlParams + "\", type:\"GET\"\n");
    		
    		H1 = new httpClient("/maestro/getChapterEquation?"+urlParams,"GET","","",true);
        	String eqnResponse = H1.httpRequest();        		
            
        	System.out.println("eqnResponse:"+utilities.json_pretty_print(eqnResponse)+"\n");
        	consoleLog.log("eqnResponse:"+utilities.json_pretty_print(eqnResponse)+"\n");
            
            if((eqnResponse != null) && (!eqnResponse.isEmpty()) && (!eqnResponse.equals("")))
    		{
	            JSONParser parser = new JSONParser();
				Object eqnObj = parser.parse(eqnResponse);
		        JSONObject jo = (JSONObject) eqnObj;
			    eqnStatus = (String) jo.get("isEquationExists");
			    
			    System.out.println("eqnStatus:"+eqnStatus);
			    
			    if(eqnStatus.equals("true"))
			    {
			    	if(new File(pathString+"Equations/"+chName).isDirectory())
			    	{
			    		consoleLog.log("This chapter has \"Equations\" and equations are present in "+pathString+"/Equations/"+chName+"\n");
			    		System.out.println("This chapter has \"Equations\" and equations are present in "+pathString+"/Equations/"+chName+"\n");
			    		eqnFolderStatus = true;
			    	}
			    	else
			    	{
			    		consoleLog.log("This chapter has \"Equations\" but equations are not present in "+pathString+"/Equations/"+chName+"\n");
			    		System.out.println("This chapter has \"Equations\" and equations are not present in "+pathString+"/Equations/"+chName+"\n");
			    		eqnFolderStatus = false;
			    		
			    		//Equatons missing
			    		if(H1.mailConstruct(templateType, "DIRECTORY", chName, "", ""))
		        			System.out.println("Mail to \""+templateType+"\" for "+chName+" sent successfully at "+U1.getLocalTime());
		        		else
		        			System.out.println("Mail to \""+templateType+"\" for "+chName+" sending failed at "+U1.getLocalTime());
			    		/*mailObj = new mail("Pre-editing", "DIRECTORY", chName, "", "");
						Thread mailThread6 = new Thread(mailObj, "Mail Thread for CRC Team");
			        	mailThread6.start();*/
			    	}
			    }
			    else if(eqnStatus.equals("false"))
			    {
			    	consoleLog.log("This chapter does not have \"Equations\"\n");
		    		System.out.println("This chapter does not have \"Equations\"\n");
		    		eqnFolderStatus = true;
			    }
    		}
        }
        
        //check template exists for the manuscripts
        if(styleSheetfileStatus && contentModellingStatus && eqnFolderStatus)
        {
        	Pattern pattern = Pattern.compile("^"+jobId);
    		Matcher matcher = pattern.matcher(chName);
    		//String suffix="";
    		
    		if(matcher.find())
    		{
    			//System.out.println("Found match at: "  + matcher.start() + " to " + matcher.end());
    			suffix = chName.substring(matcher.end(),chName.length());
        	
    			if(clientId.equals("TF_HSS"))
    			{	
	    			switch(suffix)
	    			{
		    			case "_BM":
						case "_BM_GLO":
						case "_BM_ACK":
						case "_BM_REF":
						case "_BM_BIB":
						case "_BM_IDX":
						case "_BM_SIDX":
						case "_BM_AIDX":
						case "_BM_NOTE":
						case "_BM_CI":
						case "_BM_AFWD":
						case "_BM_ATA":
						case "_BM_NOC":
						case "_BM_SAMPLE":
						{
	    					suffix = "_BM";
	    				}
	    				break;
	    					
						case "_FM":
						case "_FM_LOC":
						case "_FM_ATA":
						case "_FM_NOC":
						case "_FM_SERS":
						case "_FM_DED":
						case "_FM_ACK":
						//case "_FM_REF":
						case "_FM_INTRO":
						case "_FM_LOF":
						case "_FM_LOT":
						case "_FM_CPY":
						case "_FM_PREF":
						case "_FM_FRWD":
						case "_FM_TOC":
						case "_FM_SAMPLE":
	    					suffix = "_FM";
	    				break;
	    				
						case "_INTRO":
						case "_SAMPLE":
						case "_CON":
							suffix = "_CH";
	    				break;
							
	    				default:
	    				{
	    					if(suffix.matches("^_CH\\d\\d"))
	    						suffix = "_CH";
	    					else if(suffix.matches("^_PT\\d\\d|^_ST\\d\\d"))
	    						suffix = "_PT";
	    					else if(suffix.matches("|^_BM_APP\\d\\d"))
	    						suffix = "_BM";
	    					
	    				}
	    				break;
	    			}
    			}
    		}
        	
        	if(jobParam.get("templateName").equals(""))
        	{
        		if(new File(jobParam.get("Template")).exists())
        		{
	        		File tempDir = new File(jobParam.get("Template"));
	        		File[] listOfFiles = tempDir.listFiles();
	        		
	        		//System.out.println("templateName:"+templateName);
	        		
	        		for(int i=0; i < listOfFiles.length; i++)
	        		{
	        			if(listOfFiles[i].isFile() && (FilenameUtils.getExtension(listOfFiles[i].toString()).equals("idml")))
	        			{
	        				//String mnsSuffix = chName.substring(chName.lastIndexOf('_'),chName.lastIndexOf('_')+3);
	        				String tempFile = FilenameUtils.getBaseName(listOfFiles[i].toString());
	        				String idmlSuffix = tempFile.substring(tempFile.lastIndexOf('_'),tempFile.lastIndexOf('_')+3);
	        				templateName = tempFile.substring(0,tempFile.lastIndexOf('_'));
	        				
	        				if(suffix.equals(idmlSuffix))
	        				{
		        				tempFileStatus = true;
		        				templateFile = listOfFiles[i].toString();
		        				break;
	        				}
	    				}
	        		}
        		}
        		
        		if(!tempFileStatus)
        		{
        			System.out.println("Template file does not exists for this manuscript("+chName+").");
        			consoleLog.log("Template file does not exists for this manuscript("+chName+").");
        			
        			if(H1.mailConstruct("Template","TEMPLATE ERROR",jobId,"", "Template file does not exists for this manuscript("+chName+")."))
	        			System.out.println("Mail to \"Template\" for "+jobId+" sent successfully at "+U1.getLocalTime());
	        		else
	        			System.out.println("Mail to \"Template\" for "+jobId+" sending failed at "+U1.getLocalTime());
        			/*mail mailObj = new mail("Template","TEMPLATE ERROR",jobId,"", "Template file does not exists for this manuscript("+chName+").");
        			//mailObj.mailProcess("Template","JOB_SUCCESS","jobId","", "");
        			Thread mailThread = new Thread(mailObj, "Mail Thread for template error");
        			mailThread.start();*/
        		}
        	}
        	else
        	{
        		if(new File(jobParam.get("Template")).exists())
        		{
	        		//String mnsSuffix = chName.substring(chName.lastIndexOf('_'),chName.lastIndexOf('_')+3);
	        		String tempFile = jobParam.get("Template") + jobParam.get("templateName")+suffix+".idml";
	        		System.out.println("tempFile:"+tempFile);
	        		if(new File(tempFile).exists())
	        		{
	        			tempFileStatus = true;
	        			templateFile = tempFile;
	        		}
        		}
        		else
        		{
        			System.out.println("Template path ("+jobParam.get("Template")+ "does not exists.");
        			consoleLog.log("Template path ("+jobParam.get("Template")+ "does not exists.");
        			
        			if(H1.mailConstruct("Template","TEMPLATE ERROR",jobId,"", "* Template Name : "+templateName+"\n * Standard Template path is Invalid. ("+ jobParam.get("Template") + ")"))
	        			System.out.println("Mail to \"Template\" for "+jobId+" sent successfully at "+U1.getLocalTime());
	        		else
	        			System.out.println("Mail to \"Template\" for "+jobId+" sending failed at "+U1.getLocalTime());
        			/*mail mailObj = new mail("Template","TEMPLATE ERROR",jobId,"", "* Template Name : "+templateName+"\n * Standard Template path is Invalid. ("+ jobParam.get("Template") + ")");
        			//mailObj.mailProcess("Template","JOB_SUCCESS","jobId","", "");
        			Thread mailThread = new Thread(mailObj, "Mail Thread for template error");
        			mailThread.start();*/
        		}
        	}
        	System.out.println("templateName:"+templateName);
        }
        
        //condition for inDesign to initiate or not
        if(styleSheetfileStatus && contentModellingStatus && eqnFolderStatus && tempFileStatus)
        {
	        if(inDStyleMap.equals("true"))
	        {
	        	consoleLog.log("InDesign style map process already finished, StyleMapping function skipped.");
				System.out.println("InDesign style map process already finished, StyleMapping function skipped.");
	        }
	        else//if(styleSheetfileStatus && contentModellingStatus && eqnFolderStatus && !inDStyleMap.equals("true"))
			{
				//stylesheet file found and contentModelling stage passed
				consoleLog.log("Stylesheet file present and PreEditStatus stage passed.\n");
				System.out.println("Stylesheet file present and PreEditStatus stage passed.\n");
				
				
				while(counter.get() != 0)
		        {
		        	TimeUnit.SECONDS.sleep(1);
		        }

		        counter.incrementAndGet();
		        U1.delete(new File(System.getProperty ("user.home")+"/Desktop/Maestro_QS/"+chName+"_InDTReport.xls"));
	        	
	        	//template path, mapping path and stylesheet path 
	        	//String jobParams[] = job.getDocParam(jobId, clientId);
	        	if(JavaApplescriptTest(chName,pathString+"/"+chName+".xlsx"))
	        	{
	        		//jsx process passed
	        		jsxProcessStatus = true;
	        		
	        		//Buildpage invoke
	        		//Runtime.getRuntime().exec( new String[] { "open", "/Users/comp/Desktop/BuildPage.app"} );
	        			        		
	        	}
	        	else
	        	{
	        		consoleLog.log("Failed in InDesign style mapping stage.\n");
		    		System.out.println("Failed in InDesign style mapping stage.\n");
	        	}
	        	counter.decrementAndGet();
			}
        }
	    
		if(styleSheetfileStatus && contentModellingStatus && eqnFolderStatus && (jsxProcessStatus || inDStyleMap.equals("true")))
		{
			if(buildPageProcess(chName, suffix, templateFile, file))
			{
				System.out.println("Build page finished successfully");
				manuScripts.add(file);
				processedFiles++;
			}
			
			//Buildpage processing
			/*while(counter.get() != 0)
	        {
	        	TimeUnit.SECONDS.sleep(1);
	        }
			
			//Buildpage invoke
			counter.incrementAndGet();
			
			//"tell application "System Events" to set appNames to name of every process" get application status
			String command = "tell application \"System Events\" to set appNames to name of every process";
			String result = U1.osascript_call(command);
			System.out.println("Process(es) alive:"+result);
			
			boolean isFound = result.indexOf("Adobe InDesign CC 2014") !=-1? true: false; //true
	        boolean isFound1 = result.indexOf("BuildPage") !=-1? true: false;
	        boolean isFound2 = result.indexOf("MAMP") !=-1? true: false;
			
	        if(!isFound)
	        {
	        	command = "tell application \"Adobe InDesign CC 2014\" to activate\n" + 
	        			"with timeout of 600 seconds\n" + 
	        			"end timeout\n" + 
	        			"end";
				result = U1.osascript_call(command);
	        }
	        
	        if(!isFound1)
	        {
	        	Runtime.getRuntime().exec( new String[] { "open", System.getProperty ("user.home")+"/Desktop/BuildPage.app"} );
	        }
	        
	        if(!isFound2)
	        {
	        	command = "tell application \"MAMP\" to activate\n" + 
	        			"with timeout of 600 seconds\n" + 
	        			"end timeout\n" + 
	        			"end";
				result = U1.osascript_call(command);
	        }
	        
	        System.out.println("Supporting programs invoked.");
	        
			xmlPrj x1 = new xmlPrj();
			
			//Automation root folder
			File autRoot = new File(System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/");
			if(!autRoot.exists())
			{
				//autRoot creation
				autRoot.mkdir();				
			}
			
			//Automation root folder
			File inFolder = new File(System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/IN/");
			if(!inFolder.exists())
			{
				//autRoot creation
				inFolder.mkdir();				
			}
			
			//Automation root folder
			File outFolder = new File(System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/OUT/");
			if(!outFolder.exists())
			{
				//autRoot creation
				outFolder.mkdir();				
			}
			
			File src = new File(importMapPath);
			File dest = new File(System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/Settings/");
			
			if(!dest.exists())
			{
				dest.mkdir();
	    		TimeUnit.SECONDS.sleep(1);
			}
			
			//setting copy
			FileUtils.copyDirectory(src.getParentFile(), dest);
			
			//Automation root folder
			String jobInFolder = System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/IN/"+jobId;
			if(!new File(jobInFolder).exists())
			{
				//autRoot creation
				new File(jobInFolder).mkdir();				
			}
			
			//Automation root folder
			String jobOutFolder = System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/OUT/"+jobId;
			if(!new File(jobOutFolder).exists())
			{
				//autRoot creation
				new File(jobOutFolder).mkdir();				
			}
			
			String transform = System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/IN/"+jobId+"/transformation.xml";
			//if(new File(transform).exists())
			x1.upTrans(transform, chName);
			
			String mPrjFile="";
			
			String clientPrefix = "";
			
			if(clientId.equalsIgnoreCase("TF_STEM"))
				clientPrefix = "TFCRC";
			else if(clientId.equalsIgnoreCase("TF_HSS"))
				clientPrefix = "TFGENERIC";
			
			switch(suffix)
			{
				case "_CH":
				{
					mPrjFile = clientPrefix+"CHAP.mprj";
				}
				break;
				
				case "_PT":
				{
					mPrjFile = clientPrefix+"PART.mprj";
				}
				break;
				
				case "_FM":
				{
					mPrjFile = clientPrefix+"FM.mprj";
				}
				break;
				
				case "_RM":
				{
					mPrjFile = clientPrefix+"BM.mprj";
				}
				break;
			}
			
			x1.upMprj(dest+mPrjFile, templateName+suffix);
			
			//File folder = dest;
	        File[] listOfFiles = dest.listFiles();
	        
	        System.out.println("Processing already present files in Job folder...\n");
			consoleLog.log("Processing already present files in Job folder...\n");
			
			File mapSettings = new File(System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/Settings/");
			
			if(dest.exists() && suffix.contains("FM"))
			{
				for (int i = 0; i < listOfFiles.length; i++) 
				{
					if (listOfFiles[i].isDirectory()) 
					{
						mapSettings = listOfFiles[i];
						File[] listOfFiles2 = listOfFiles[i].listFiles();
						String suffix2 = suffix.replace("_","").toLowerCase();
						suffix2 = suffix2+"_ii_map";
						for (int j = 0; j < listOfFiles2.length; j++) 
						{
							if (listOfFiles[j].isFile() 
									&& FilenameUtils.getExtension(listOfFiles[j].toString()).equals(".xml")
									&& listOfFiles[j].toString().contains(suffix2)) 
							{
								x1.upInddMap(listOfFiles[j].toString(), templateName+suffix);
							}
						}
					}
				}
			}
			
			String localTemplLoc = mapSettings.toString()+FilenameUtils.getName(templateFile);
			
			System.out.println("(Local)templateFile:"+localTemplLoc);
			System.out.println("(Server)templateFile:"+templateFile);
			
			//copy template file
			Files.copy(Paths.get(templateFile), Paths.get(localTemplLoc),StandardCopyOption.REPLACE_EXISTING);
			
			//copy manuscript file to IN folder
			Files.copy(Paths.get(pathString+"/"+file), Paths.get(jobInFolder+"/"+file), StandardCopyOption.REPLACE_EXISTING);
			
			//buildpage url : http://localhost:8888/automation/me_submit.php?projectfile=TFGENERICBM.mprj&transformfile=transformation.xml&jobid=9874561230001&output=TEXT
    		String url1 = "/automation/me_submit.php?projectfile="+mPrjFile+"&transformfile=transformation.xml&jobid="+jobId+"&output=TEXT";
			H1 = new httpClient(url1,"GET","","",false);
			String runid = H1.httpRequest();
			System.out.println("bpResp:"+runid);
			
			url1 = "/automation/getJobStatus.php?runid="+runid;
			H1 = new httpClient(url1,"GET","","",false);
			String jobStatus = H1.httpRequest();
			System.out.println("jobStatus:"+jobStatus);
			
			while(!jobStatus.equalsIgnoreCase("SUCCESS"))
			{
				url1 = "/automation/getJobStatus.php?runid="+runid;
				H1 = new httpClient(url1,"GET","","",false);
				jobStatus = H1.httpRequest();
				//waiting for jobs to finish from buildpage
				TimeUnit.SECONDS.sleep(1);
			}
			System.out.println("jobStatus:"+jobStatus);
			//Buildpage close
			counter.decrementAndGet();*/
		}
		else
		{
			//Move manuscripts to error folder
        	File theDir = new File(pathString+"ERROR/");
        	while (!theDir.exists()) 
			{
        		theDir.mkdir();
			}
        	U1.fileMove(pathString+"/"+chName+".docx",pathString+"ERROR/"+chName+".docx");
			if(U1.fileCheck(pathString +"/"+chName+".xlsx"))
				U1.fileMove(pathString+"/"+chName+".xlsx",pathString+"ERROR/"+chName+".xlsx");
			//processedFiles--;
		}
		
		System.out.println("No of manuscripts : "+noOfManuScripts);
		System.out.println("No of processedFiles : "+processedFiles+"\n");
		
		consoleLog.log("No of manuscripts : "+noOfManuScripts);
		consoleLog.log("No of processedFiles : "+processedFiles+"\n");
		return (styleSheetfileStatus && contentModellingStatus && jsxProcessStatus);
	}
	
	private boolean buildPageProcess(String chName, String suffix, String templateFile, String file) throws Exception
	{
		boolean bpStatus = false;
		//Buildpage processing
		while(counter.get() != 0)
        {
        	TimeUnit.SECONDS.sleep(1);
        }
		
		//Buildpage invoke
		counter.incrementAndGet();
		
		//"tell application "System Events" to set appNames to name of every process" get application status
		String command = "tell application \"System Events\" to set appNames to name of every process";
		String result = U1.osascript_call(command);
		System.out.println("Process(es) alive:"+result);
		
		boolean isFound = result.indexOf("Adobe InDesign CC 2014") !=-1? true: false; //true
        boolean isFound1 = result.indexOf("BuildPage") !=-1? true: false;
        boolean isFound2 = result.indexOf("MAMP") !=-1? true: false;
		
        if(!isFound)
        {
        	command = "tell application \"Adobe InDesign CC 2014\" to activate\n" + 
        			"with timeout of 600 seconds\n" + 
        			"end timeout\n" + 
        			"end";
			result = U1.osascript_call(command);
        }
        
        if(!isFound1)
        {
        	Runtime.getRuntime().exec( new String[] { "open", System.getProperty ("user.home")+"/Desktop/BuildPage.app"} );
        }
        
        if(!isFound2)
        {
        	command = "tell application \"MAMP\" to activate\n" + 
        			"with timeout of 600 seconds\n" + 
        			"end timeout\n" + 
        			"end";
			result = U1.osascript_call(command);
        }
        
        System.out.println("Supporting programs invoked.");
        
		xmlPrj x1 = new xmlPrj();
		
		//Automation root folder
		File autRoot = new File(System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/");
		if(!autRoot.exists())
		{
			//autRoot creation
			autRoot.mkdir();				
		}
		
		//Automation root folder
		File inFolder = new File(System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/IN/");
		if(!inFolder.exists())
		{
			//autRoot creation
			inFolder.mkdir();				
		}
		
		//Automation root folder
		File outFolder = new File(System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/OUT/");
		if(!outFolder.exists())
		{
			//autRoot creation
			outFolder.mkdir();				
		}
		
		File src = new File(importMapPath);
		File dest = new File(System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/Settings/");
		
		if(!dest.exists())
		{
			dest.mkdir();
    		TimeUnit.SECONDS.sleep(1);
		}
		
		//setting copy
		FileUtils.copyDirectory(src.getParentFile(), dest);
		
		//Automation root folder
		String jobInFolder = System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/IN/"+jobId;
		if(!new File(jobInFolder).exists())
		{
			//autRoot creation
			new File(jobInFolder).mkdir();				
		}
		
		//Automation root folder
		String jobOutFolder = System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/OUT/"+jobId;
		if(!new File(jobOutFolder).exists())
		{
			//autRoot creation
			new File(jobOutFolder).mkdir();				
		}
		
		String transform = System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/IN/"+jobId+"/transformation.xml";
		//if(new File(transform).exists())
		x1.upTrans(transform, chName);
		
		String mPrjFile="";
		
		String clientPrefix = "";
		
		if(clientId.equalsIgnoreCase("TF_STEM"))
			clientPrefix = "TFCRC";
		else if(clientId.equalsIgnoreCase("TF_HSS"))
			clientPrefix = "TFGENERIC";
		
		switch(suffix)
		{
			case "_CH":
			{
				mPrjFile = clientPrefix+"CHAP.mprj";
			}
			break;
			
			case "_PT":
			{
				mPrjFile = clientPrefix+"PART.mprj";
			}
			break;
			
			case "_FM":
			{
				mPrjFile = clientPrefix+"FM.mprj";
			}
			break;
			
			case "_RM":
			{
				mPrjFile = clientPrefix+"BM.mprj";
			}
			break;
		}
		
		//x1.upMprj(dest+mPrjFile, templateName+suffix);
		x1.upMprj(dest+"/"+mPrjFile, templateName+suffix);
		
		//File folder = dest;
        File[] listOfFiles = dest.listFiles();
        
        System.out.println("Processing already present files in Job folder...\n");
		consoleLog.log("Processing already present files in Job folder...\n");
		
		File mapSettings = new File(System.getProperty ("user.home")+"/Desktop/Maestro/Automation Root/Settings/");
		
		if(dest.exists())
		{
			for (int i = 0; i < listOfFiles.length; i++) 
			{
				if (listOfFiles[i].isDirectory()) 
				{
					mapSettings = listOfFiles[i];
					if(suffix.contains("FM"))
					{
						File[] listOfFiles2 = listOfFiles[i].listFiles();
						String suffix2 = suffix.replace("_","").toLowerCase();
						suffix2 = suffix2+"_ii_map";
						for (int j = 0; j < listOfFiles2.length; j++) 
						{
							if (listOfFiles[j].isFile() 
									&& FilenameUtils.getExtension(listOfFiles[j].toString()).equals(".xml")
									&& listOfFiles[j].toString().contains(suffix2)) 
							{
								x1.upInddMap(listOfFiles[j].toString(), templateName+suffix);
							}
						}
					}
				}
			}
		}
		
		String localTemplLoc = mapSettings.toString()+"/"+FilenameUtils.getName(templateFile);
		
		System.out.println("(Local)templateFile:"+localTemplLoc);
		System.out.println("(Server)templateFile:"+templateFile);
		
		//copy template file
		Files.copy(Paths.get(templateFile), Paths.get(localTemplLoc),StandardCopyOption.REPLACE_EXISTING);
		
		//copy manuscript file to IN folder
		Files.copy(Paths.get(pathString+"/"+file), Paths.get(jobInFolder+"/"+file), StandardCopyOption.REPLACE_EXISTING);
		
		//buildpage url : http://localhost:8888/automation/me_submit.php?projectfile=TFGENERICBM.mprj&transformfile=transformation.xml&jobid=9874561230001&output=TEXT
		String url1 = "/automation/me_submit.php?projectfile="+mPrjFile+"&transformfile=transformation.xml&jobid="+jobId+"&output=TEXT";
		H1 = new httpClient(url1,"GET","","",false);
		String runid = H1.httpRequest();
		System.out.println("bpResp:"+runid);
		
		url1 = "/automation/getJobStatus.php?runid="+runid;
		H1 = new httpClient(url1,"GET","","",false);
		String jobStatus = H1.httpRequest();
		System.out.println("jobStatus:"+jobStatus);
		
		while(!jobStatus.equalsIgnoreCase("SUCCESS") && !jobStatus.equalsIgnoreCase("ERROR"))
		{
			url1 = "/automation/getJobStatus.php?runid="+runid;
			H1 = new httpClient(url1,"GET","","",false);
			jobStatus = H1.httpRequest();
			//waiting for jobs to finish from buildpage
			TimeUnit.SECONDS.sleep(1);
			
		}
		System.out.println("jobStatus:"+jobStatus);
		if(jobStatus.equalsIgnoreCase("SUCCESS"))
		{
			bpStatus = true;
			System.out.println("(BUILDPAGE)JOB Success, IDML created successfully.");
		}
		else if(jobStatus.equalsIgnoreCase("ERROR"))
		{
			System.out.println("(BUILDPAGE)JOB finished with ERROR.");
		}
		//Buildpage close
		counter.decrementAndGet();
		return bpStatus;
	}
	
	@SuppressWarnings("unchecked")
	public boolean JavaApplescriptTest(String chName,String stylePath) throws IOException
	 {
		boolean appleScriptStatus = false;
		String result = "";
		
		//System.out.println("jobId:"+jobId);
		//System.out.println("clientId:"+clientId);
		//System.out.println("chName:"+chName);
		System.out.println("templateName : "+templateName);
		System.out.println("templatePath:"+templatePath);
		System.out.println("styleSheetPath:"+styleSheetPath);
		System.out.println("mapPath:"+importMapPath+"\n");
		
		consoleLog.log("templateName : "+templateName);
		consoleLog.log("templatePath : "+templatePath);
		consoleLog.log("styleSheetPath : "+styleSheetPath);
		consoleLog.log("mapPath : "+importMapPath+"\n");
		//ScriptEngineManager manager = new ScriptEngineManager();
		//ScriptEngine engine = manager.getEngineByName("AppleScript");
		//String pathFolder = path.get(i).substring(path.get(i).indexOf("//")+2,path.get(i).length());
		
		try 
		{
			String command = "set aScriptPath to \"Users:"+System.getProperty ("user.name")+":Library:Preferences:Adobe InDesign:Version 10.0:en_US:Scripts:Scripts Panel:Maestro_Styles_Validations_v1.0.jsx\"\n" +
			"set myParameters to {\""+ clientId +"\",\"" + jobId +"\", \"" + chName +".docx\", \"" + stylePath +"\",\"" + templateName +"\",\"" + templatePath +"\", \"" + importMapPath +"\",\"" + styleSheetPath +"\"}\n" +
			"tell application \"Adobe InDesign CC 2014\"\n" +
			"with timeout of 600 seconds\n" +
			"Activate\n" +
			"do script aScriptPath language javascript with arguments myParameters\n"+ 
			"tell script args \n" +
			"set myScriptArgumentA to get value name \"ScriptArgumentB\"\n" +
			"end tell\n" +
			"end timeout\n" +
			"return myScriptArgumentA \n" +
			"end tell\n";
			
			//System.out.println("command:"+command);
			
			System.out.println("InDesign Processing.....");
			consoleLog.log("InDesign Processing.....");
			
			result = U1.osascript_call(command);
			System.out.println("Applescript response:"+utilities.json_pretty_print(result));
			consoleLog.log("Applescript response:"+utilities.json_pretty_print(result));
			if((result != null) && (!result.isEmpty()) && (!result.equals("")))
			{
				JSONParser parser = new JSONParser();
				if(((String) result).charAt(0) == '{' )
				{
					Object appleScrObj = parser.parse((String) result);
					JSONObject jo = (JSONObject) appleScrObj;
			        String response = (String) jo.get("response");
			        if(response.equals("200") || response.equals("404"))
			        {
			        	if(response.equals("200"))
			        	{
			        		appleScriptStatus = true;
			        		//appleScriptStatus  = 1;
			        		//url call
			        		JSONObject obj=new JSONObject();
			        		obj.put("jobId",jobId);
			        		obj.put("clientId",clientId);
			        		obj.put("chapterName",chName);
			        		obj.put("inDTemplateStatus","true");
			        		//System.out.println(JSONValue.toJSONString(obj));
			        		//consoleLog.log(JSONValue.toJSONString(obj));
			        		
			        		consoleLog.log("URL : /maestro/updateChapterTemplateStatus" + ", type : \"PUT\" and content : \""+JSONValue.toJSONString(obj)+"\"");
			        		
			        		H1 = new httpClient("/maestro/updateChapterTemplateStatus","PUT",JSONValue.toJSONString(obj),"",true);
			        		String urlResponse = H1.httpRequest();
			        		
			        		System.out.println("Response:"+utilities.json_pretty_print(urlResponse));
			        		consoleLog.log("Response:"+utilities.json_pretty_print(urlResponse));
			        		//consoleLog.log("Response:"+url.putUrlRequest());
			        		
			        		JSONObject obj1=new JSONObject();
			        		obj1.put("jobId",jobId);
			        		obj1.put("clientId",clientId);
			        		//"chapterDate":"28-06-2018 20:01:03",
			        		//"styleSheetModifiedDate": "26-06-2018 23:01:00"
			        		
			        		System.out.println("Before Format : " + new File(pathString + "/" + chName + ".docx").lastModified());
			            	SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			            	System.out.println("After Format : " + sdf.format(new File(pathString + "/" + chName + ".docx").lastModified()));
			        		
			        		obj1.put("chapterDate",sdf.format(new File(pathString + "/" + chName + ".docx").lastModified()));
			        		obj1.put("styleSheetModifiedDate",sdf.format(new File(pathString + "/" + chName + ".xlsx").lastModified()));
			        		
			        		consoleLog.log(JSONValue.toJSONString(obj1));
			        		System.out.println(JSONValue.toJSONString(obj1));
			        		
			        		consoleLog.log("URL : /maestro/updateStatus, type : \"PUT\" and content : "+JSONValue.toJSONString(obj1)+"\"");
			        		
			        		H1 = new httpClient("/maestro/updateStatus","PUT",JSONValue.toJSONString(obj1),"",true);
			        		urlResponse = H1.httpRequest();
			        		
			        		consoleLog.log("Response:"+utilities.json_pretty_print(urlResponse)+"\n");
			        		System.out.println("Response:"+utilities.json_pretty_print(urlResponse));
			        		
			        		//String chName;
			        		
			        		//sample : sendMail("CRC Team", "SUCCESS", "9781138556850_Ilyas_CH01", "", "");
			        		//sending mail to CRC Team
			        		if(H1.mailConstruct(URLEncoder.encode(templateType, "UTF-8"),"SUCCESS",chName,"", ""))
			        			System.out.println("Mail to \""+templateType+"\" for "+chName+" sent successfully at "+U1.getLocalTime());
			        		else
			        			System.out.println("Mail to \""+templateType+"\" for "+chName+" sending failed at "+U1.getLocalTime());
			        		/*mailObj = new mail(URLEncoder.encode("CRC Team", "UTF-8"),"SUCCESS",chName,"", "");
			    			//mailObj.mailProcess(URLEncoder.encode("CRC Team", "UTF-8"),"SUCCESS",chName.substring(0,chName.indexOf(".docx")),"", "");
			    			Thread mailThread7 = new Thread(mailObj, "Mail Thread for CRC Team");
			            	mailThread7.start();*/
			            	
			            	//sample : sendMail("Template", "SUCCESS", "9781138556850_Ilyas_CH01", "", "");
			            	//sending mail to Template Team
			        		if(H1.mailConstruct("Template","SUCCESS",chName,"", ""))
			        			System.out.println("Mail to \"Template\" for "+chName+" sent successfully at "+U1.getLocalTime());
			        		else
			        			System.out.println("Mail to \"Template\" for "+chName+" sending failed at "+U1.getLocalTime());
			        		
			        		/*mailObj = new mail("Template","SUCCESS",chName,"", "");
			    			//mailObj.mailProcess("Template","ERROR",chName.substring(0,chName.indexOf(".docx")),System.getProperty ("user.home")+"/Desktop/Maestro_QS/"+chName.substring(0,chName.indexOf(".docx"))+"_InDTReport.xls", "");
			    			Thread mailThread8 = new Thread(mailObj, "Mail Thread for Template Team");
			            	mailThread8.start();*/
			            	
			            	System.out.println("InDesign process finished Successfully.\n");
			            	consoleLog.log("InDesign process finished Successfully.\n");
			        	}
			        	else if(response.equals("404"))
			        	{
			        		String templateStatus = (String) jo.get("status");
			        		System.out.println("templateStatus:"+templateStatus);
			        		consoleLog.log("templateStatus:"+templateStatus);
			        		
			        		//sample : sendMail("CRC Team", "ERROR", "9781138556850_Ilyas_CH01", "", "");
			            	//sending mail to Template Team
//			        		mailObj = new mail(URLEncoder.encode("CRC Team", "UTF-8"),"ERROR",chName,System.getProperty ("user.home")+"/Desktop/Maestro_QS/"+chName+"_InDTReport.xls", "");
//			    			//mailObj.mailProcess(URLEncoder.encode("CRC Team", "UTF-8"),"SUCCESS",chName.substring(0,chName.indexOf(".docx")),"", "");
//			    			Thread mailThread9 = new Thread(mailObj, "Mail Thread for CRC Team");
//			            	mailThread9.start();
			        		String attachment = "";
			        		
			        		//check for attachment
			        		if(new File(System.getProperty ("user.home")+"/Desktop/Maestro_QS/"+chName+"_InDTReport.xls").exists())
			        		{	
			        			attachment = System.getProperty ("user.home")+"/Desktop/Maestro_QS/"+chName+"_InDTReport.xls";
			        			/*mailObj = new mail("Template","ERROR",chName,attachment, templateStatus);
				    			//mailObj.mailProcess("Template","ERROR",chName.substring(0,chName.indexOf(".docx")),System.getProperty ("user.home")+"/Desktop/Maestro_QS/"+chName.substring(0,chName.indexOf(".docx"))+"_InDTReport.xls", "");
				    			Thread mailThread10 = new Thread(mailObj, "Mail Thread for Template Team");
				            	mailThread10.start();*/
			        		}
			        		
			        		if(H1.mailConstruct("Template","ERROR",chName,attachment, templateStatus))
			        			System.out.println("Mail to \"Template\" for "+chName+" sent successfully at "+U1.getLocalTime());
			        		else
			        			System.out.println("Mail to \"Template\" for "+chName+" sending failed at "+U1.getLocalTime());
			        		
			        		System.out.println("InDesign process finished with Error.\n");
			            	consoleLog.log("InDesign process finished with Error.\n");
			        	}
			        }
				}
	        }
			else
			{
				System.out.println("InDesign could not access the \"Generic/standard style sheet\".");
        		consoleLog.log("InDesign could not access the \"Generic/standard style sheet\".");
				
        		if(H1.mailConstruct(URLEncoder.encode(templateType, "UTF-8"),"ERROR",chName,"", ""))
        			System.out.println("Mail to \""+templateType+"\" for "+chName+" sent successfully at "+U1.getLocalTime());
        		else
        			System.out.println("Mail to \""+templateType+"\" for "+chName+" sending failed at "+U1.getLocalTime());
				/*mailObj = new mail(URLEncoder.encode("CRC Team", "UTF-8"),"ERROR",chName,"", "");
    			//mailObj.mailProcess(URLEncoder.encode("CRC Team", "UTF-8"),"SUCCESS",chName.substring(0,chName.indexOf(".docx")),"", "");
    			Thread mailThread9 = new Thread(mailObj, "Mail Thread for CRC Team");
            	mailThread9.start();*/
			}
		 } 
		 catch (Exception e) 
		 {
			consoleLog.log(e.toString());
		 }
		 return appleScriptStatus;
	 }
	 
	/*private static String json_pretty_print(String json)
	{
		if(!json.isEmpty())
		{
			json = json.replace("{","{\n    ");
			json = json.replace(",",",\n    ");
			json = json.replace("}","\n}");
			//System.out.println("JSON:"+json);
			return json;
		}
		else
			return "";
	}*/
	 //templatePath, mapPath and used styles path details check
	 /*void jobParam()
	 {
		 try
		 {
			 String urlParams = "jobId="+URLEncoder.encode(jobId,"UTF-8")+"&clientId="+URLEncoder.encode(clientId,"UTF-8");//+"&chapter="+URLEncoder.encode(temp,"UTF-8")
	 		//local server 172.16.4.112, live - 172.16.1.25
	     	
	     	consoleLog.log("URL:\"http://"+url_request.serverIp+"/maestro/getTemplatePathDetails?"+urlParams + "\",type:\"GET\"\n");
	     	String templateResponse = url_request.urlRequestProcess("http://"+url_request.serverIp+"/maestro/getTemplatePathDetails?"+urlParams,"GET","");
	 		System.out.println("templateResponse:"+json_pretty_print(templateResponse));
	 		consoleLog.log("templateResponse:"+json_pretty_print(templateResponse)+"\n");
	 		
	 		if((!templateResponse.isEmpty()) && (!templateResponse.equals("")))
			{
	 			String templateNameLoc,templatePathLoc,importMapPathLoc,styleSheetPathLoc;
	 			
		 		JSONParser parser = new JSONParser();
				Object templateObj = parser.parse(templateResponse);
		        JSONObject jo = (JSONObject) templateObj;
			
		        templateNameLoc = (String) jo.get("templateName");
		        templatePathLoc = (String) jo.get("templatePath");
		        importMapPathLoc = (String) jo.get("maestroMappingPath");
		        styleSheetPathLoc = (String) jo.get("styleSheetPath");
		        
		        if(((templateNameLoc != null) && (!templateNameLoc.equals("")) && (!templateNameLoc.isEmpty())) 
		        	&& ((templatePathLoc != null) && (!templatePathLoc.equals("")) && (!templatePathLoc.isEmpty()))
		        	&& ((importMapPathLoc != null) && (!importMapPathLoc.equals("")) && (!importMapPathLoc.isEmpty()))
		        	&& ((styleSheetPathLoc != null) && (!styleSheetPathLoc.equals("")) && (!styleSheetPathLoc.isEmpty())))
		        {
		        	templatePathLoc = templatePathLoc.replace('\\','/');
		        	importMapPathLoc = importMapPathLoc.replace('\\','/');
		        	styleSheetPathLoc = styleSheetPathLoc.replace('\\','/');
		        	
		        	templatePathLoc = templatePathLoc.substring(templatePathLoc.indexOf("//")+2,templatePathLoc.length());
		        	templatePathLoc = templatePathLoc.substring(templatePathLoc.indexOf('/')+1,templatePathLoc.length());
		        	templatePathLoc = "/Volumes/"+templatePathLoc; //templatePath
		    		
		        	importMapPathLoc = importMapPathLoc.substring(importMapPathLoc.indexOf("//")+2,importMapPathLoc.length());
		        	importMapPathLoc = importMapPathLoc.substring(importMapPathLoc.indexOf('/')+1,importMapPathLoc.length());
		        	importMapPathLoc = "/Volumes/"+importMapPathLoc; //maestro mapping path
		    		
		        	styleSheetPathLoc = styleSheetPathLoc.substring(styleSheetPathLoc.indexOf("//")+2,styleSheetPathLoc.length());
		        	styleSheetPathLoc = styleSheetPathLoc.substring(styleSheetPathLoc.indexOf('/')+1,styleSheetPathLoc.length());
		        	styleSheetPathLoc = "/Volumes/"+styleSheetPathLoc; //styleSheetPath
		    		
//		        	System.out.println("templatePath : "+jobParams[1]);
//		    		System.out.println("maestroMappingPath : "+jobParams[2]);
//		    		System.out.println("styleSheetPath : "+jobParams[3]+"\n");
//		    		
//		    		consoleLog.log("templatePath : "+jobParams[1]);
//		    		consoleLog.log("maestroMappingPath : "+jobParams[2]);
//		    		consoleLog.log("styleSheetPath : "+jobParams[3]+"\n");
		        	
		    		boolean templatePathStatus = utilities.folderCheck(templatePathLoc);
		    		boolean maestroMappingPathStatus = utilities.folderCheck(importMapPathLoc);
		    		boolean styleSheetPathStatus = utilities.fileCheck(styleSheetPathLoc);
		    		
		    		System.out.println("fileCheckStatus of templatePath : "+templatePathStatus);
		    		System.out.println("fileCheckStatus of maestroMappingPath : "+maestroMappingPathStatus);
		    		System.out.println("fileCheckStatus of styleSheetPath : "+styleSheetPathStatus+"\n");
		    		
		    		consoleLog.log("fileCheckStatus of templatePath : "+templatePathStatus);
		    		consoleLog.log("fileCheckStatus of maestroMappingPath : "+maestroMappingPathStatus);
		    		consoleLog.log("fileCheckStatus of styleSheetPath : "+styleSheetPathStatus+"\n");
		    		
		    		if(!templatePathStatus && !maestroMappingPathStatus && !styleSheetPathStatus)
		    		{
		    			templateName = "";
		    			templatePath = "";
		    			importMapPath = "";
		    			styleSheetPath = "";
		    		}
		    		else
		    		{
		    			templateName = templateNameLoc;
		    			templatePath = templatePathLoc;
		    			importMapPath = importMapPathLoc;
		    			styleSheetPath = styleSheetPathLoc;
		    		}
		        }
		        else
		        {
		        	templateName = "";
	    			templatePath = "";
	    			importMapPath = "";
	    			styleSheetPath = "";
		        }
	 		}
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
		 return;
	 }*/
	 
	private boolean isCompletelyWritten(File file) throws InterruptedException
    {
        Long fileSizeBefore = FileUtils.sizeOf(file);//size(file.toPath());
        Thread.sleep(3000);
        Long fileSizeAfter = FileUtils.sizeOf(file);//size(file.toPath());

        //System.out.println("comparing file size " + fileSizeBefore + " with " + fileSizeAfter);
        if (fileSizeBefore.equals(fileSizeAfter)) 
        {
            return true;
        }
        System.out.println("Copying.........");
        return false;
    }
	 
	void suspend() 
	{
		suspended = true;
	}
	   
	void resume() 
	{
		suspended = false;
		//notify();
	}
	
	private boolean fileNameRegex(String jobId, File file)
	{
		boolean status = false;
		String fileName = FilenameUtils.getBaseName(file.toString()),suffix="";
		Pattern pattern = Pattern.compile("^"+jobId);
		Matcher matcher = pattern.matcher(fileName);
		
		if(matcher.find())
		{
			//System.out.println("Found match at: "  + matcher.start() + " to " + matcher.end());
			suffix = fileName.substring(matcher.end(),fileName.length());
			//System.out.println("suffix : "+suffix);
			if(clientId.equals("TF_HSS"))
			{
				switch(suffix)
				{
					case "_BM":
					case "_BM_GLO":
					case "_BM_ACK":
					case "_BM_REF":
					case "_BM_BIB":
					case "_BM_IDX":
					case "_BM_SIDX":
					case "_BM_AIDX":
					case "_BM_NOTE":
					case "_BM_CI":
					case "_BM_AFWD":
					case "_BM_ATA":
					case "_BM_NOC":
					case "_BM_SAMPLE":
					case "_FM":
					case "_FM_LOC":
					case "_FM_ATA":
					case "_FM_NOC":
					case "_FM_SERS":
					case "_FM_DED":
					case "_FM_ACK":
					//case "_FM_REF":
					case "_FM_INTRO":
					case "_FM_LOF":
					case "_FM_LOT":
					case "_FM_CPY":
					case "_FM_PREF":
					case "_FM_FRWD":
					case "_FM_TOC":
					case "_FM_SAMPLE":
					case "_INTRO":
					case "_CON":
					case "_SAMPLE":
						status = true;
						break;
						
					default:
					{
						if(suffix.matches("^_CH\\d\\d|^_BM_APP\\d\\d|^_PT\\d\\d|^_ST\\d\\d"))
							status = true;
						break;
					}
				}
			}
		}
		return status;
	}
}