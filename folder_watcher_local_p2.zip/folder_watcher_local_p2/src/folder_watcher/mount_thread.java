package folder_watcher;

import java.util.concurrent.TimeUnit;

public class mount_thread implements Runnable
{
	private utilities U1;
	public void run()
	{
		try 
		{
			while(true)
			{
				TimeUnit.SECONDS.sleep(50);
				String command = "try\n" + 
					"	do shell script \"killall NetAuthAgent\"\n" + 
					"on error\n" + 
					"	return\n" + 
					"end try";
				U1 = new utilities();
				U1.osascript_call(command);
			}
		}
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
